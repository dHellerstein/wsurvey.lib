23 Feb 2022

Several php "libraries" used by wsurvey.

Most of these (wsurvey.getJson and wsurvey.uploadFiles) are meant be used with with similarly named javascript libraries.
