June 2022

A suite of javascript libraries.
Some of them (wsurvey.getJson and wsurvey.uploadFiles) are meant to work with similarly named php files.

See the ../doc/ directory for a description and documentation for each of these .js files.

Note: the min/ subdirectory contains minify'ied versions of these.
