March 2022 / March 2023 / December 2023 / Jan 2024 
wsurvey.lib contains various useful libraries comprising the wsurvey. package.
Most of them are used by one of the wsurvey. apps.

 doc: : documenation and description of both js and php libraries
 examples: demos of the usage of these libraries
 js : javascript libraries
 php  : php libraries
 publicLib : public domain (not part of wsurvey.) javascript and php libraries. That are, or may be, used in wsurvey.

Latest versions of these can be found at  http://www.wsurvey.org/distrib, or  https://github.com/dHellerstein

