// wsurvey : local storage library
// requires wsurvey libraries
//   wsurvey.utils1.js
//and libraries packaged with wsurvey:
//   md5b.js
//   aes.js


if (typeof(wsurvey)=='undefined') var wsurvey={};       // make the wsurvey namespace

wsurvey.localStorage={} ;  // define a "namespace" for functions

wsurvey.localStorage.initData={'groups':{},'defaultGroup':''};      //  for initialization data

// not currently supported
//wsurvey.localStorage.errFunc='alert';   // how to display errors. SHould be initialzed to something more useful by calling program

//===================================
//=================

//   initialize a "group"
//   The value of group MUST be a string. numbers and letters, and @, _ and . are permitted.
//       Other characters, including spaces, are NOT permitted.
//       It is converted to lowercase
//   aencrypt is optional -- false is used if not specified
//       IF specified (and not false) its value should be a string: the encryption key (used to
//        encrypt and decrypt localStorage data). This key can have any characters
//  quiet
///    how to return.
//    0 :  return a string with a status message
//               An alert is done if there is an error, and return false
//    1 : return [status,message] ... status is true or false (true=success, false means failure)
//  isDefault: 0 or 1. 0 is the default (if not specified)
//          0 : if this is the first group specified (during a session), this is the default group
//           1 : set this to be the default group
//           The default group is used when no group/ is specified in .get, .set, .remove, or .list

wsurvey.localStorage.init=function(agroup,aencrypt,isDefaultGroup,quiet) {
  if (arguments.length<2) aencrypt=false ;
  if (arguments.length<3) isDefaultGroup=0 ;
  if (arguments.length<4) quiet=0 ;

  if (typeof(agroup)!=='string') {
     if (quiet==1) return [false,'wsurvey.localStorage.init: group not a string'];
     alert('wsurvey.localStorage.init: group not a string');
     return false;
  }
  let okGroup=wsurvey.localStorage.groupNameBad(agroup) ;
  if (okGroup!==false) {
     let oo=okGroup.join(', ');
     let oo2='wsurvey.localStorage.init: group ('+agroup+') has unallowed characters: '+oo;
     if (quiet==1) return [false,oo2];
     alert(oo2);
     return false;
  }

  let qok=wsurvey.localStorage.storageAvailable();
  if (!qok) {
     if (quiet==1) return [false,'wsurvey.localStorage.init: localStorage not enabled on this browser '];
     alert('wsurvey.localStorage.init: localStorage not enabled on this browser ');
     return false;
  }

  agroup=agroup.toLowerCase();
  if (aencrypt!==false) {
     if (jQuery.trim(aencrypt)=='') aencrypt=false;
  }

  wsurvey.localStorage.initData['groups'][agroup]={};
  wsurvey.localStorage.initData['groups'][agroup]['encrypt']=false ;
  
   if (wsurvey.localStorage.initData['defaultGroup']=='' || isDefaultGroup==1) {
       wsurvey.localStorage.initData['defaultGroup']=agroup;
   }

  if (aencrypt!==false) {
           aencrypt=jQuery.trim(aencrypt);
           if (aencrypt=='') aencrypt=false;
           if (aencrypt!==false) {
             if (typeof(aencrypt)=='string') {
                  amd5=md5(aencrypt)
                  wsurvey.localStorage.initData['groups'][agroup]['encrypt']={'key':aencrypt,'md5':amd5} ;
              }
           }
  }

  if  (aencrypt!==false) {
      if (quiet==1) return [true,' initialized, with encryption enabled ('+aencrypt+') '];
      return agroup+' initialized, with encryption enabled ('+aencrypt+') ';
  } else {
      if (quiet==1) return [true,agroup+' initialized '];
      return agroup+' initialized ';
  }

}


//=============================
// store value into local storage
//   avar : variable name. Can be groupName/varname or varname
//             i.e.;  mygroup/var100
//      group and varname  contain alphanumerics, ., _, and @. I.e.; no spaces
//         If no groupName/ spcified, varname is not in a group - and is NOT subject to DEFAULT encryption
//  aval : value to store. Can be a plainObject, string, or number
//  aencrypt : encryption key. 
//           If not specified, or true: use the group default
//           If '', or false, do NOT encrypt
//           Otherwise, the encryption key to use
//            If true or '': do NOT encrypt (even if group is encrypted)
//  quiet: if 0, return true or error string
//        if 1, return [status,message ] (status= true or false)

wsurvey.localStorage.set=function(avar0,aval,quiet,myAencrypt) {
   if (arguments.length<3) quiet=0;
   if (arguments.length<4) myAencrypt=true;     // use group defaults

   let noEncrypt=false;

   if (myAencrypt===false || jQuery.trim(myAencrypt)=='') noEncrypt=true;  // signal to NOT encrypt

   let varP=wsurvey.localStorage.parseName(avar0);
   if (varP[1]==false) {
     let oo2='wsurvey.localStorage.set error: '+varP[0];
     if (quiet==1) return [false,oo2];
     alert(oo2);
     return false;
   }

    let agroup=varP[0];
    let avar=varP[1];
    let akey=varP[2];
    let keyMd5=varP[3];

    if (noEncrypt===false) {          // 3rd arg="true" meanse "use group defaults)
        if (myAencrypt!==true)  {  // custom encryptiong
           akey=myAencrypt;
           keyMd5=md5(akey);
        }
     }             // noEncrypt

   Stamp = new Date();
   let atimeStamp=Stamp.getTime()  ;

// encrypt?
   if (akey!==false) {
      let avalX=JSON.stringify(aval);
      let encObj=CryptoJS.AES.encrypt(avalX, akey);          // encrypt the stringified
      let  encString=encObj.toString();                                // extract the text that contains the encrypted/stringified object
      stuff={'data':encString,'keyMd5':keyMd5,'time':atimeStamp};          // a non-'' key signals that data is stringifyied/encrypted
   } else {
      stuff={'data':aval,'keyMd5':'','time':atimeStamp};          // don't encrypt
   }

// now save!
   let stuff1=JSON.stringify(stuff) ;   // value might be double stringified and encrtyped !

   let saveVar='wsurveyLocalStorage_'+agroup+'/'+avar;
   try {
      localStorage.setItem(saveVar,stuff1);    // Initializing userlist
      let saveVar2=  'wsurveyLocalStorage_'+agroup+' lastUpdate/';
      let Stamp = new Date();
      let atimeStamp=Stamp.getTime()  ;
      localStorage.setItem(saveVar2,atimeStamp);    // used by groupExists

   } catch(err) {    // should not happen, but who knows
       let amess='wsurvey.localStorage.set: problem saving to local storage:  '+err ;
        if (quiet==1) return [false,amess];
       alert(amess);
       return amess;
   }

   let amess='Saved: '+avar0;
   if (akey!==false) amess+=' (encrypted)' ;
   if (quiet==1) return [true,amess];

   return true;     // dont' alert

 }

//=============================
// get value from local storage
//   avar : variable name. Can be groupName/varname or varname
//             i.e.;  mygroup/var100
//      group and varname  contain alphanumerics, ., _, and @. I.e.; no spaces
//         If no groupName/ specified, varname is not in a group - and is NOT subject to DEFAULT encryption
//  aencrypt : encryption key. If not specified, or true, or '' : use the group specific default
//           If false or '', do NOT decrypt
//             otherwise use the aencrypt (a string)
//  quiet: if 0, return true or error string
//        if 1, return [status,value,timestamp,localStorageVarName,keyMD5 ]
//          status= true or false)
//          localStorageName may have "default group" appended to varname
//          keyMd5 is md5 of encyrption key (that worked)
//

wsurvey.localStorage.get=function(avar0,quiet,myAencrypt) {

   if (arguments.length<2) quiet=0;
   if (arguments.length<3) myAencrypt=true;     // use group defaults

   let noEncrypt=false;

   if (myAencrypt===false || jQuery.trim(myAencrypt)=='') noEncrypt=true;  // signal to NOT encrypt

   let undef ;
   let avar='', agroup ;
   let akey=false,keyMd5 ;  // default is no encrytion

   let varP=wsurvey.localStorage.parseName(avar0);
   if (varP[1]==false) {
     let oo2='wsurvey.localStorage.get error: '+varP[0];
     if (quiet==1) return [false,oo2];
     alert(oo2);
     return false;
   }

     agroup=varP[0];
     avar=varP[1];
     akey=varP[2];         // might be '' (i.e.; if not in a group)
     keyMd5=varP[3];
   
   if (noEncrypt==true) {     // do   not decrypt
      akey='';
      keyMd5='';
   } else {                      //use custom encryption key
       if (myAencrypt!==true) {
          akey=myAencrypt;
          keyMd5=md5(akey);
       }
   }          // else gropu specificencryption eky

   let saveVar='wsurveyLocalStorage_'+agroup+'/'+avar;
   let vuse;
   try {
      vuse=localStorage.getItem(saveVar);    // Initializing userlist
      if (vuse===null){
          if (quiet==1) return [true,vuse];
          return vuse ;        // null means "not set"
      }
   } catch(err) {    // should not happen, but who knows
       let amess='wsurvey.localStorage.get: problem reading from local storage:  '+err ;
        if (quiet==1) return [false,amess];
       alert(amess);
       return amess;
   }

// decrypt?
   let vt=JSON.parse(vuse);
   let adate=vt['time'];
   if (vt['keyMd5']=='' || noEncrypt===true) {
      if (quiet==1) return [true,vt['data'],adate,saveVar,vt['keyMd5']];
      return vt['data'] ; // not encrypted -- ignore any encryiton key (in group, or in arguments)
   }

// does savedWith md5 match supplied md5?
   if (vt['keyMd5']!=keyMd5) {
       let amess='wsurvey.localStorage.get: incorrect encryption key';
       if (quiet==1) return [false,amess];
       alert(amess);
       return undef ;      // undefined signals "bad encryption"
   }

  let decryptedBytes = CryptoJS.AES.decrypt(vt['data'], akey);
  try {              // could be an error....
    plaintext = decryptedBytes.toString(CryptoJS.enc.Utf8);
    let data1=JSON.parse(plaintext);
    if (quiet==1) return [true,data1];
    return data1 ;  // no alert
  } catch(err) {    // should not happen, but who knows
       let amess='wsurvey.localStorage.get: unable to decrypt: '+err;
       if (quiet==1) return [false,amess];
       alert(amess);
       return undef ;      // undefined signals "bad encryption"
   }

}

//=============================
// remove  value from local storage
//   avar : variable name. Can be groupName/varname or varname
//             i.e.;  mygroup/var100
//      group and varname  contain alphanumerics, ., _, and @. I.e.; no spaces
//         If no groupName/ specified, varname is not in a group - and is NOT subject to DEFAULT encryption
//  quiet: if 0, return true or error string
//        if 1, return [status,message ] (status= true or false)

wsurvey.localStorage.remove=function(avar0,quiet) {

   if (arguments.length<2) quiet=0;

   let varP=wsurvey.localStorage.parseName(avar0);
   if (varP[1]==false) {
     let oo2='wsurvey.localStorage.remove error: '+varP[0];
     if (quiet==1) return [false,oo2];
     alert(oo2);
     return false;
   }

   let agroup=varP[0];
   let avar=varP[1];

// don't check encryption (its too easy for a mean user of a computer to delete  from local storage via browser settings

   let saveVar='wsurveyLocalStorage_'+agroup+'/'+avar;

   let vuse;
   try {
     let oof=localStorage.getItem(saveVar);
     if (oof===null) {
        if (quiet==1) return [false,'no such variable: '+saveVar];
         return false;
     }

      vuse=localStorage.removeItem(saveVar);    // Initializing userlist
      if (quiet==1) return [true,saveVar];
      return true;
   } catch(err) {    // should not happen, but who knows
       let amess='wsurvey.localStorage.remove: problem removing from local storage:  '+err ;
        if (quiet==1) return [false,amess];
       alert(amess);
       return amess;
   }

}


//=============================
// get list of varialbes in a group, as an object:
//  agroup: group to find variables fgor. '' for "not in a group". Do NOT include a /
//  quiet: if 0, return true or error string
//        if 1, return [status,message ] (status= true or false)
//
// returns varlist:
//    {'var1':timestamp,'var2':timestamp}
//   avar : variable name. Can be groupName/varname or varname
//             i.e.;  mygroup/var100
//  quiet:   varLis ,   or error string
//        if 1, return [status,message or varList ] (status= true or false)
//
wsurvey.localStorage.list=function(agroup,quiet) {
  if (arguments.length<2) quiet=0;

  agroup=jQuery.trim(agroup);
  if (agroup==='') agroup= wsurvey.localStorage.initData['defaultGroup'] ;
  if (agroup=='') {
      let amess='wsurvey.localStorage.list error: no group specified (and no default group)';
      if (quiet==1) return [false,amess];
      alert(amess);
      return amess;
  }
  agroup=agroup.toLowerCase();
  if (agroup!=='')  {  // make sure group has been initialized
      if (!wsurvey.localStorage.initData['groups'].hasOwnProperty(agroup)) {
         let amess='wsurvey.localStorage.list: no such group='+agroup ;
        if (quiet==1) return [false,amess];
         alert(amess);
         return false  ;
      }
 }
 apre='wsurveyLocalStorage_'+agroup+'/';
 let alistX=[] ;
  let ilen=apre.length ;
  for (let i = 0; i < localStorage.length; i++) {
     let aname=localStorage.key(i) ;

     if (typeof(aname)!='string') continue;
     let aname0=aname.substr(0,ilen);
     if (aname0!==apre) continue ;
      let anameUse=aname.substr(ilen);
      vuse=localStorage.getItem(aname);    // Initializing userlist
      let vtmp=JSON.parse(vuse);
      let adate=vtmp['time'];
      let ug=[anameUse,aname,adate];
      alistX.push(ug);
   }
   if (quiet==1) return [true,alistX,agroup];
   return alistX;

}

//==============
// clear all variables in a group, and remove from group list
wsurvey.localStorage.clear=function(agroup,quiet) {
  if (arguments.length<2) quiet=0;

  agroup=jQuery.trim(agroup);
  if (agroup=='') {
      let amess='wsurvey.localStorage.clear error: no group specified  ';
      if (quiet==1) return [false,amess];
      alert(amess);
      return false;
  }
   if (!wsurvey.localStorage.initData['groups'].hasOwnProperty(agroup)) {
         let amess='wsurvey.localStorage.clear: no such group='+agroup+' ('+agroup+')';
        if (quiet==1) return [false,amess];
        alert(amess);
        return false  ;
 }
  
  agroup=agroup.toLowerCase();
  let  apre='wsurveyLocalStorage_'+agroup+'/';
  let  apre2='wsurveyLocalStorage_'+agroup+' lastUpdate/';

  let ilen=apre.length ;
  let ilen2=apre2.length ;
  let removes=[];
  for (let i = 0; i < localStorage.length; i++) {
     let aname=localStorage.key(i) ;
     if (typeof(aname)!='string') continue;
     let aname0=aname.substr(0,ilen);
     if (aname0!==apre) {       // not group/varname, might be group lastUdpate
          if (aname!=apre2) continue;
      }
      removes.push(aname);
  }
  let nremoves=removes.length;
  for (let ir=0;ir<nremoves;ir++) {
      let aname0=removes[ir]
      localStorage.removeItem(aname0);    // remove
   }
   delete  wsurvey.localStorage.initData['groups'][agroup];
   if (wsurvey.localStorage.initData['groups']['defaultGroup']==agroup) wsurvey.localStorage.initData['groups']['defaultGroup']='' ;
   if (quiet==1) return [true,nremoves];
   return nremoves ;
}

//===================
// summary of all active groups: [groupname]{[varList], 'isDefault':true/false}
// no arguments 

wsurvey.localStorage.summary=function(ifoo) {
  let summary={} ;
 
  for (let agroup in  wsurvey.localStorage.initData['groups']) {
       apre='wsurveyLocalStorage_'+agroup+'/';

       let alistX=[],isdef=0 ;
       let ilen=apre.length ;
       for (let i = 0; i < localStorage.length; i++) {
          let aname=localStorage.key(i) ;
          if (typeof(aname)!='string') continue;
          let aname0=aname.substr(0,ilen);
          if (aname0!==apre) continue ;
          let anameUse=aname.substr(ilen);
          alistX.push(anameUse);
       }
       isdef= (wsurvey.localStorage.initData['defaultGroup'] == agroup ) ? true : false;
       let aa={'list':alistX,'isDefault':isdef}
       summary[agroup]=aa;
   }             // agroup 
   return summary;
}


//================
// return json'ized string of all variables in group (stringified object)
// Suitable for use with  survey.localStorage.restore

wsurvey.localStorage.archive=function(agroup,quiet) {
  if (arguments.length<2) quiet=0;

  agroup=jQuery.trim(agroup);
  if (agroup=='') {
      let amess='wsurvey.localStorage.archive error: no group specified  ';
      if (quiet==1) return [false,amess];
      alert(amess);
      return false;
  }
   if (!wsurvey.localStorage.initData['groups'].hasOwnProperty(agroup)) {
         let amess='wsurvey.localStorage.archive: no such group='+agroup+' ('+agroup+')';
        if (quiet==1) return [false,amess];
        alert(amess);
        return false  ;
 }
  agroup=agroup.toLowerCase();

  apre='wsurveyLocalStorage_'+agroup+'/';
  let ilen=apre.length ;
  let abase='wsurveyLocalStorage_';
  let ilen0=abase.length ;

  let shows=[];
  let undefv ;  // undefined
  for (let i = 0; i < localStorage.length; i++) {
     let aname=localStorage.key(i) ;
     if (typeof(aname)!='string') continue;
     let aname0=aname.substr(0,ilen);
     if (aname0!==apre) continue ;
     let fullname=aname.substr(ilen0);
 
     shows.push([aname,aname.substr(ilen),fullname ]);
  }
 //  wsurvey.dumpObj(shows,1,'shows in archive');
  let nshows=shows.length;
  res1={};
  errs=[];
  for (let ir=0;ir<nshows;ir++) {
     let anameUse=shows[ir][1];
     anameGet=shows[ir][2];
     vv1= wsurvey.localStorage.get(anameGet,1)  ;
     if (vv1[0]==false) {
         errs.push(vv1[1]);
         continue;
     }
     res1[anameUse]=vv1[1];
  }
   if (errs.length>0) {
      if (quiet==1)  return [false,res1,errs] ;
      alert('wsurvey.localStorage.archive: '+errs.length+' problems');
      return false;;
   }
   let sres=JSON.stringify(res1);
    if (quiet==1)  return [true,sres,errs]  ;
    return res1 ;

}


//================
// restore from a json'ized string produced by .archive

wsurvey.localStorage.restore=function(agroup,astring,quiet) {
    if (arguments.length<3) quiet=0;
  agroup=jQuery.trim(agroup);

  if (agroup=='') {
      let amess='wsurvey.localStorage.restore error: no group specified  ';
      if (quiet==1) return [false,amess];
      alert(amess);
      return false;
  }
   if (!wsurvey.localStorage.initData['groups'].hasOwnProperty(agroup)) {
         let amess='wsurvey.localStorage.restore: no such group='+agroup+' ('+agroup+')';
        if (quiet==1) return [false,amess];
        alert(amess);
        return false  ;
 }

 agroup=agroup.toLowerCase();

 let vv;
 try {
      vv=JSON.parse(astring);
 } catch(err) {
      let amess='wsurvey.localStorage.restore: error parsing string = '+err ;
      if (quiet==1) return [false,amess];
      alert(amess);
      return false  ;
 }

  let shows=[];
  let undefv ;  // undefined
  let nokay=0,nerr=0;
  for (let aname in vv) {
     let aval=vv[aname];
     let useName=agroup+'/'+aname;
     let x1=wsurvey.localStorage.set(useName,aval,1) ;
     if (x1[0]==true) {
         nokay++;
     } else {
         nerr++;
     }
  }
  if (nerr>0) {
      let amess='# restored='+nokay+', and '+nerr+' errors ';
      if (quiet==1) [false,amess];
      alert('wsurvey.localStorage.restore: '+amess);
      return false ;
  }

  if (quiet==1) return [true,nokay];
  return true ;


}

// =======================================
// return or set the defaultGroup
wsurvey.localStorage.setDefaultGroup=function(agroup,quiet) {

  if (arguments.length<1) {      // special case: get the current default group
     let bgroup=  wsurvey.localStorage.initData['defaultGroup'] ;
     if (quiet==1) return [true,bgroup];
     return  bgroup ;
  }

  if (arguments.length<2) quiet=2;

  agroup=jQuery.trim(agroup);

  if (agroup=='') {
      let amess='wsurvey.localStorage.restore error: no group specified  ';
      if (quiet==1) return [false,amess];
      alert(amess);
      return false;
  }
   if (!wsurvey.localStorage.initData['groups'].hasOwnProperty(agroup)) {
         let amess='wsurvey.localStorage.restore: no such group='+agroup+' ('+agroup+')';
        if (quiet==1) return [false,amess];
        alert(amess);
        return false  ;
 }
 wsurvey.localStorage.initData['defaultGroup']=agroup ;
 if (quiet==1) return [true,agroup];
 return  true ;

}

//===============
// check if group exists. Or return a list of all groups
wsurvey.localStorage.groupExists=function(agroup,quiet) {

  if (arguments.length<2) quiet=2;
  let allGroups=false;
  
  let qok=wsurvey.localStorage.storageAvailable();
  if (!qok) {
     if (quiet==1) return [false,'wsurvey.localStorage.groupExists: localStorage not enabled on this browser '];
     alert('wsurvey.localStorage.groupExists: localStorage not enabled on this browser ');
     return false;
  }

  if (jQuery.trim(agroup)=='*') {
     allGroups=true;;
  } else {
     let okGroup=wsurvey.localStorage.groupNameBad(agroup) ;
     if (okGroup!==false) {
       let oo=okGroup.join(', ');
        let oo2='wsurvey.localStorage.groupExists: group ('+agroup+') has unallowed characters: '+oo;
        if (quiet==1) return [false,oo2];
       alert(oo2);
       return false;
     }
  }

// just look for one
 if (allGroups==false) {
   let alook='wsurveyLocalStorage_'+agroup+' lastUpdate/';
   vuse=localStorage.getItem(alook);
   if (vuse===null) {
      if (quiet==1) return [true,false];
      return true;
    } else  {
       if (quiet==1) return [true,parseInt(vuse)];
       return parseInt(vuse);
    }
  }

// find all groups
  let listX={};
  let apre='wsurveyLocalStorage_';
  let ilen=apre.length ;
  for (let i = 0; i < localStorage.length; i++) {
     let aname=localStorage.key(i) ;
     let aname0=aname.substr(0,ilen);
     if (aname0!==apre) continue ;
     let iIndex=aname.indexOf(' lastUpdate/');
     if (iIndex>0) {  // special variable: last update (set by .set()
          vuse=localStorage.getItem(aname);
          let tii=iIndex-ilen ;
          let bgroup=aname.substr(ilen,tii);
          listX[bgroup]=vuse;
     }
  }
  if (quiet==1) return [true,listX];
  return listX;

}


// =======================================
// ---- helper functions

//===========
// parse group/varname. Return [group,var], or [ errorMessage,false]
wsurvey.localStorage.parseName=function(avar0) {
   let islash=avar0.indexOf('/');
   let defaultGroup= wsurvey.localStorage.initData['defaultGroup'] ;

   if (islash<0) {    // no group
     if (defaultGroup==='')  {  // no default group ... error!
          let oo2='group not specified, and no default group ('+avar0+')' ;
          return [oo2,false];
      }
      agroup=defaultGroup;
      avar=avar0 ;

   } else {
      avar=avar0.substr(islash+1);
      if (islash==0) {
        if (defaultGroup==='')  {  // no default group ... error!
            let oo2='group is not specified, and no default group ('+avar0+')' ;
            return [oo2,false];
        }
        agroup=defaultGroup;
     } else {
       agroup=avar0.substr(0,islash);
       agroup=agroup.toLowerCase();
     }
   }

   if (jQuery.trim(avar)=='') {
     let oo2='varname not specified ('+avar0+')' ;
     return [oo2,false];
   }


   let avarBad=wsurvey.localStorage.groupNameBad(avar) ;
   if (avarBad!==false) {
     let oo=avarBad.join(', ');
     let oo2='var ('+avar0+') has unallowed characters: '+oo;
     return [oo2,false];
   }

   avar=avar.toLowerCase();

   if (agroup!==false)  {  // make sure group has been initialized
      if (!wsurvey.localStorage.initData['groups'].hasOwnProperty(agroup)) {
         let amess='wsurvey.localStorage.set: no such group='+agroup+' ('+avar0+')';
         return [amess,false];
      }
    }

//    if (agroup===false ||  jQuery.trim(agroup)=='')  return [agroup,avar,'',''];  // no group, so no  default encryption key

// default encryption key for this group
   aencrypt0=wsurvey.localStorage.initData['groups'][agroup]['encrypt'];
  if (aencrypt0===false) return [agroup,avar,false,''];

   akey=aencrypt0['key'];
   keyMd5=aencrypt0['md5'];
   return [agroup,avar,akey,keyMd5];

}

//===============
//https://developer.mozilla.org/en-US/docs/Web/API/Web_Storage_API/Using_the_Web_Storage_API
// check if local storage is available
wsurvey.localStorage.storageAvailable=function(atype) {
  let type='localStorage'
  let storage;
  try {
    storage = window[type];
    const x = "__storage_test__";
    storage.setItem(x, x);
    storage.removeItem(x);
    return true;
  } catch (e) {
    return (
      e instanceof DOMException &&
      // everything except Firefox
      (e.code === 22 ||
        // Firefox
        e.code === 1014 ||
        // test name field too, because code might not be present
        // everything except Firefox
        e.name === "QuotaExceededError" ||
        // Firefox
        e.name === "NS_ERROR_DOM_QUOTA_REACHED") &&
      // acknowledge QuotaExceededError only if there's something already stored
      storage &&
      storage.length !== 0
    );
  }
}



//===
// valid names ?
wsurvey.localStorage.groupNameBad=function(agroup1) {
    let isnull=null;
    let arf=  agroup1.match(/\,|\s|"|'|`|#|\\|\/|\%|!|\+|\&|~|\*|\$|\||\<|\>/gi);   // unallowed characters
    if (arf===isnull)      return false ;
    let ares=[] ;
    for (let ii=0;ii<arf.length;ii++) if (arf[ii]===' ') arf[ii]='space' ;
    for (let ii=0;ii<arf.length;ii++) if (arf[ii]===',') arf[ii]='comma' ;
    return arf ;
}     // groupNameBad


