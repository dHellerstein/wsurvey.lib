///=============
// display an object in a new window. This is a fancier version of wsuvey.dumpObj 
// a1: variable (an object or array)   -- or string or number
// asay: message
// isay: 0 - show as text, 1=ask first, show as text or html depending on answer (in a prompt popup box), 11= show at html no promptini
function showDebug(a1,asay,isay) {
  let xx=a1;
  dohtml=0;

  let acolors=['lime','cyan'];
  let acolors2=['#c1dadb;','#d0dbc1;'];
  let acolors3=['#dcd9cc;','#ded8d0;'];
  let acolors4=['#dcd9fc;','#ded8f0;'];
  let icolor=0,icolor2=0,icolor3=0,icolor4=0;

  if (arguments.length<2) asay=' showing ' ;

  if (arguments.length<3) isay=0 ;
  let arg3=2;

   if (typeof(a1)=='string' || typeof(a1)=='number') {
     if (arguments.length<2) asay=a1 ;
     xx=a1   ;
     arg3=1;
   }
   let xx2=wsurvey.dumpObj(xx ,'var','var: '+asay);
   if (isay==1) {
       qq=prompt('showDebug (0=skip,1=text,2=html)?  '+asay,arg3);
       qq=parseInt(qq);
       if (qq!=1 && qq!=2) return 0;
       if (qq==2) dohtml=1;
   }
   if (isay==11) dohtml=1;

   let vv=xx2.split('\n');

   let notClass=['','','','','',
                      'notMain',
                      'notMain notSecond',
                      'notMain notSecond notThird',
                      'notMain notSecond notThird notFourth',
                      'notMain notSecond notThird notFourth notFifth',
                      'notMain notSecond notThird notFourth notFifth notSixth',
                      'notMain notSecond notThird notFourth notFifth notSixth notSeventh',
                      'notMain notSecond notThird notFourth notFifth notSixth notSeventh notEigth'];

   let vv2=[];
   let atable='<div style="max-height:85vh;overflow:auto;margin:0.34em 5px 1em  5px;padding:3px">';
     atable+='<table style="table-layout:fixed" cellpadding="2"  border="1" xrules="rows">';
    atable+='<tr bgcolor="#dfefdf">';
    atable+='<th> 1 ';
      atable+='</th>';
    atable+='<th class="thStuff thStuff2"> 2 <input type="button" value="&#128065;" title="show all secondary and below " data-ith="1" onClick="hideCol(this,1)"> ';
      atable+='<input type="button" value="&#9938;" title="hide all secondary and below "  data-ith="1" onClick="hideCol(this,0)"> ';
      atable+='</th>';
    atable+='<th class="thStuff thStuff3 "> 3 <input type="button" value="&#128065;" title="show all tertiary and below " data-ith="2" onClick="hideCol(this,1)"> ';
      atable+='<input type="button" value="&#9938;" title="hide all tertiary and below "  data-ith="2" onClick="hideCol(this,0)"> ';
      atable+='</th>';
    atable+='<th class="thStuff thStuff4"> 4 <input type="button" value="&#128065;" title="show all 4th level and below " data-ith="3" onClick="hideCol(this,1)"> ';
      atable+='<input type="button" value="&#9938;" title="hide all 4th level and below "  data-ith="3" onClick="hideCol(this,0)"> ';
      atable+='</th>';
    atable+='<th class="thStuff thStuff5"> 5 <input type="button" value="&#128065;" title="show all 5th level and below " data-ith="4" onClick="hideCol(this,1)"> ';
      atable+='<input type="button" value="&#9938;" title="hide all 5th level and below " data-ith="4" data-ith="4" onClick="hideCol(this,0)"  > ';
      atable+='</th>';
    atable+='<th class="thStuff thStuff6">  6 <input type="button" value="&#128065;" title="show all 5th level and below  " data-ith="5" onClick="hideCol(this,1)"> ';
      atable+='<input type="button" value="&#9938;" title="hide all 5th level and below "  data-ith="5" onClick="hideCol(this,0)"> ';
      atable+='</th>';
    atable+='<th class="thStuff thStuff7">   7 <input type="button" value="&#128065;" title="show all 5th level and below " data-ith="6" onClick="hideCol(this,1)"> ';
      atable+='<input type="button" value="&#9938;" title="hide all 5th level and below " data-ith="6" onClick="hideCol(this,0)"> ';
      atable+='</th>';
    atable+='<th class="thStuff thStuff8"> 8 ';
      atable+='</th>';
    atable+='<th class="thStuff thStuff9"> 9 ';
      atable+='</th>';

   atable+'</tr>';
   let priors=[];
   let mains=[],seconds={},mainVar='',secondVar='',thirdVar='',fourthVar='';
   let maxCtc=0,alinenumUse='';
   iline=0;

   for (let i1=2;i1<vv.length;i1++) {
      let aline=vv[i1];
      let ctc=aline.substr(0,3);
      ctc=ctc.replace(/\*/g,'');
      ctc=ctc.replace(/\t/g,'');
      let ado=jQuery.trim(aline.substr(6));
      let icolon=ado.indexOf(':');
      if (icolon<0) continue ;  // skip end of object or array block
      let avar=jQuery.trim(ado.substr(0,icolon));
      avar=jQuery.trim(avar.replace(/\*/g,''));
      let arest=ado.substr(icolon+1);
      let icolon2=arest.indexOf(':');
      let atype=jQuery.trim(arest.substr(0,icolon2));
      let aval=jQuery.trim(arest.substr(icolon2+1));
      isObject=0;
      iline++ ;

      let alinenum='<span  style="backclass="colNumber">'+iline+'</span> ';
      if (atype.substr(0,6)=='object' || atype.substr(0,5)=='array') {
          aval='<tt>'+atype+'</tt>';
          isObject=1;
      } else {
         aval=aval.replace(/\"/g,'');
      }
      let add1='';
      ctc=parseInt(ctc);
      maxCtc=Math.max(maxCtc,ctc-2);

      let ictc= (ctc<notClass.length) ? ctc : notClass.length-1 ;
      let anotClass=notClass[ictc];
      if (ctc==4) {
          add1='<tr class="'+anotClass+'" >';
          priors[0]=avar;
          mains.push(avar);
          let nmains=mains.length;
          mainVar=avar;
          icolor2=0;
          seconds[mainVar]=[];
          let ajump='<a style="background-color:#efdfef" href="#top0">&#8613;</a> ';
          let aclear='<input type="button" value="&#128065;" title="toggle this set" onClick="$(\'.row_'+mainVar+'\').toggle()"> ';
          
          icolor=1-icolor ;
           alinenumUse='<span style="background-color:'+acolors[icolor]+'">'+alinenum+'</span>';
          add1+='<td bgcolor="#dfdfdf">'+alinenumUse+ajump+aclear+'<b><u><a name="jump_'+nmains+'">'+wsurvey.htmlspecialchars(avar)+'</a></u></b></td>';

          let avalUse=aval;
          if (atype.substr(0,6)=='string') avalUse='<span style="color:blue">'+wsurvey.htmlspecialchars(aval)+'</span>';
          add1+='<td bgcolor="#dfdfdf"><tt>  '+avalUse+'</tt></td></tr>';

      } else {
//           add1='<tr class="notMain row_'+mainVar+' ">';
         add1='<tr class="'+anotClass+' row_'+mainVar+' ">';
         for (let jj=4;jj<ctc;jj++) {
           if (jj==4) {
             alinenumUse='<span style="background-color:'+acolors[icolor]+'">'+alinenum+'</span>';
             add1+='<td>'+alinenumUse+'<span class="colEm">'+priors[jj-4]+'</span></td>';
           } else {
             let aprior=priors[jj-4] ;
             if (jj==5) {
                if ( aprior!==secondVar) {
                     icolor2=1-icolor2;
                     icolor3=0;
                     secondVar=aprior;
                }
                let aprior2='<span style="background-color:'+acolors2[icolor2]+'">'+aprior+'</span>';
                add1+='<td><span class="colEm">'+aprior2+'</span></td>';
             } else if (jj==6) {
                if (aprior!==thirdVar) {
                     icolor3=1-icolor3;
                     thirdVar=aprior;
                }
                let aprior3='<span style="background-color:'+acolors3[icolor3]+'">'+aprior+'</span>';
                add1+='<td><span class="colEm">'+aprior3+'</span></td>';
             } else if (jj==7) {
                if (aprior!==fourthVar) {
                     icolor4=1-icolor4;
                     fourthVar=aprior;
                }
                let aprior3='<span style="background-color:'+acolors4[icolor4]+'">'+aprior+'</span>';
                add1+='<td><span class="colEm">'+aprior3+'</span></td>';

             } else {
                add1+='<td><span class="colEm"> '+aprior+'</span></td>';
             }
           }
           priors[ctc-4]=avar;

         }
         if (isObject==0) {

           if (atype.substr(0,6)=='string') aval='<span style="color:blue">'+wsurvey.htmlspecialchars(aval)+'</span>';
           add1+='<td><u>'+wsurvey.htmlspecialchars(avar)+'</u></td><td> <tt>'+aval+'</tt></td></tr>';
         } else {
           add1+='<td  bgcolor="#dfdfdf" ><u>'+wsurvey.htmlspecialchars(avar)+'</u></td><td  bgcolor="#dfdfdf"><tt>'+aval+'</tt></td></tr>';
         }

      }
      atable+=add1;
   }
   atable+='</table>';
   atable+='</div>';

  if (dohtml==0) {
    wsurvey.displayInNewWindow('',{'content':'<pre>'+xx2+'</pre>'});
  } else {
    let ahdr='';
                          // #cfdfef
     ahdr+='<div style="max-height:3.0em;min-height:1.5em;background-color:#cfdfef;padding:2px 5px 1em 5px;overflow:auto">';

     ahdr+='<input type="button" value="&#9883;" title="only show primary var"onClick="$(\'.notMain\').hide()">   ';
     ahdr+='<input type="button" value="&#127377;" title="clear secondary var names "onClick="$(\'.colEm\').toggleClass(\'clearme\')">   ';
    ahdr+='<a name="top0">var:</a> '+asay+'  <br>';

    for (let ia=0;ia<mains.length;ia++) {
       let ia2=ia+1;
       let aname=mains[ia];
       ahdr+=' <a style="border:1px solid blue;margin:3px 5px" href="#jump_'+ia2+'">'+aname+'</a>    ';
    }
    ahdr+='</div>';

    let acss='<style type="text/css"> \n';
    acss+='.colEm {font-size:90%;font-style:oblique ; } \n';
    acss+='.colNumber {min-width:3em;font-size:80%;font-family:monospace;background-color:#dfdade; } \n';
    acss+='.clearme {display:none !important } \n';
    acss+='.colGray {display:none !important } \n';
    acss+='.thStuff {width:10em;background-color:#dfefdf; } \n';
    acss+='.hiButton {border:2px solid lime !important;background-color:yellow !important } \n';
    if (maxCtc<9)  acss+='.thStuff9 {display:none !important }  \n';
    if (maxCtc<8)  acss+='.thStuff8 {display:none !important }  \n';
    if (maxCtc<7)  acss+='.thStuff7 {display:none !important }  \n';
    if (maxCtc<6)  acss+='.thStuff6 {display:none !important }  \n';
    if (maxCtc<5)  acss+='.thStuff5 {display:none !important }  \n';
    if (maxCtc<4)  acss+='.thStuff4 {display:none !important }  \n';
    if (maxCtc<3)  acss+='.thStuff3 {display:none !important }  \n';


    acss+='.thSmall {width:7.3em !important; font-size:70% !important;padding:0px !important ;background-color:#e8e9c7; !important } \n';

    acss+='</style> ';

    ascript='<script type="text/javascript" > \n' ;
    ascript+='function hideCol(athis,ishow) { \n ' ;
    ascript+='let ethis=jQuery(athis); \n ';
    ascript+=' let ith0=ethis.attr(\'data-ith\'); let ith=ith0-1; \n ';
    ascript+='let nots=[\'notMain\',\'notSecond \',\'notThird \',\'notFourth\',\'notFifth\',\'notSixth\',\'notSeventh\',\'notEigth\'] ; \n';
    ascript+='let ado=nots[ith] ; \n ';
    ascript+='let eth=ethis.closest(\'th\'); \n ';
    ascript+='if (ishow==0) { \n ';
    ascript+='  $(\'.\'+ado).hide() ;   \n ';
    ascript+='   eth.addClass(\'hiButton\') ; \n ';
    ascript+='   for (let jj=ith+3;jj<=9;jj++) { \n ';
    ascript+='      let e2=$(\'.thStuff\'+jj); \n  ';
    ascript+='      e2.addClass(\'thSmall\');\n ';
    ascript+='   } \n ';

    ascript+=' } else { \n ';
    ascript+='  $(\'.\'+ado).show() ;    \n ';
    ascript+='  for (let jj=ith+3;jj<=9;jj++) { \n ';
    ascript+='    let e2=$(\'.thStuff\'+jj); \n ';
    ascript+='     e2.removeClass(\'thSmall\');\n ';
    ascript+='   } \n ';

    ascript+='eth.removeClass(\'hiButton\') ; \n ';



    ascript+='} ;\n ';
    ascript+=' \n ';

    ascript+=' \n ';
    ascript+=' \n ';
    ascript+=' \n ';

    ascript+='} ';

    ascript+='</script>\n'  ;

     wsurvey.displayInNewWindow('',{'content':acss+ascript+ahdr+'<p>'+atable,'jsFiles':'lib/jquery-3.6.0.min.js'});
  }

   if (isay==1) alert('Showing: '+asay);
}
