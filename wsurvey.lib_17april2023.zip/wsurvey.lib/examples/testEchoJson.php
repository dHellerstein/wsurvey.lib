<?php

// demo of  wsurvey.uploadFiles.json()
// to do the var_dump test, move the testme.json to the folder this is script is located in

if (array_key_exists('testNow',$_REQUEST))  {  // save it call
 $acurdir=getcwd();
 $libdir=dirname($acurdir);
 $getit=$libdir.'/php/wsurvey.uploadFiles.php';
 require_once($getit);
 wsurvey\uploadFiles\echoBack();
 exit;
}

if (array_key_exists('view',$_REQUEST))  {  // save it call
  $acurdir=getcwd();
  $afile=$acurdir.'/testMe.json';
  print "Contents of uploaded file: $afile <br>";
  $ado=file_get_contents($afile);
  $ajson=json_decode($ado,true);
   var_dump($ajson);
  exit;
}

//otherwise, set up the html form
?>
<!DOCTYPE HTML>
<html><head><title>demo of uploadFiles utility function: echoJson</title>
<meta charset="utf-8">


<script type="text/javascript" src="../publicLib/jquery-3.6.0.min.js"></script>
<script type="text/javascript" src="../js/wsurvey.utils1.js">  </script>
<script type="text/javascript" src="../js/wsurvey.uploadFiles.js">  </script>


<script type="text/javascript" >
 
function doit(x) {
  let a0={'me':'daniel','age':56};
  let aa={'hello':'this is hello','bye':'this is byed','fungus':895271.1232,'other':a0};

  wsurvey.dumpObj(aa,1,'The array to be saved: ');
  wsurvey.uploadFiles.echoJson(aa,'testEchoJson.php','testMe.json',{'testNow':'1'});
}

</script>
</head>
<body>
<h4>Demo of wsurvey.uploadFiles.echoJson</h4>
Click to upload a simple json file (to be saved as testMe.json): <input type="button" value="go" onClick="doit(1)">
<br>

And  then you can
<a href="testEchoJson.php?view=1" target="view1">var_dump()</a> it.
</body>
</html>
