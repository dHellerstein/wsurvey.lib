<!DOCTYPE html>
<?php

?>
<html><head>
<meta charset="utf-8">
<title>Test of wsurvey.adminLogon</title>

<style type="text/css">
.goo {
   border:3px solid blue;
  background-color:tan;
}
</style>

<script type="text/javascript" src="../publicLib/jquery-3.6.0.min.js"></script>

<script type="text/javascript" src="../js/wsurvey.utils1.js">  </script>
<script type="text/javascript" src="../js/wsurvey.adminLogon.js"></script>

<script type="text/javascript">

function init1(xx) {
  let data={'whenCall':2,'callbackLogon':'test_logonCallback','logonName':"default",'pwd':''};
   $('#logonButton2').on('click',data,wsurvey.adminLogon);
}

function test_logonCallback(amode,auser,timeLeft) {
    if (amode==0) {
        alert('Try again! ');
        return 0;
    }
   let e1=$('#response1');
   e1.html('Response: mode='+amode+' | logonname='+auser+' :: timeleft='+timeLeft);
}


function test_logonCallback_full(amode,auser,timeLeft) {
   let e1=$('#response2');
   e1.html('arguments to callback: mode='+amode+' | logonname='+auser+'| timeleft='+timeLeft);

   if (amode=='new') {
 
      $('#menu2').show();
      $('#results3').hide();

   }

   if (amode=='yes') {
     $('#results3').html('Correct password!' ).show();
     $('#menu2').fadeOut();
        return 1;
   }

   if (amode=='prior') {
       $('#results3').html('Prior logon still active!');
      $('#menu2').fadeOut();
       return 1;
   }
   if (amode=='no') {
       $('#results3').html('inCorrect password, try again! ').show();
       $('#menu2').show();
       return 1;
   }
   if (amode=='expired') {
       $('#results3').html('Prior logon expired. Please enter password.').show();
       $('#menu2').show();
       return 1;
   }

}

function submitPassword2(athis) {
   let ed1=$('#yourPassword');
   let apwd=ed1.val();
   wsurvey.adminLogon(apwd,'test_logonCallback_full','',1);
}




function byebye(amode,acontent) {
  alert('logoff from LogonName='+amode+'  \n content='+acontent);
}


function checkStatus(x) {
  let localStatus= wsurvey.adminLogon_status('');
  $('#statusHere').html('Local status =' +localStatus);
    wsurvey.adminLogon_status('','checkStatus2');
}
function checkStatus2(tt) {
   $('#statusHere').append(' ||  from server: '+tt.join(', ') ) ;
}

 var wsurveyadminlogon_quiet=0;    // do not suppress
  var wsurveyadmin_logonClass='';    // use default styling

</script>
</head>


<body onload="init1()" >
<h4>Test of wsurvey.adminLogon </h4>
Note: for logoName=<tt>default</tt> : pwd=<tt>a</tt>.
For logonName=<tt>dogName</tt> : pwd=<tt>fido</tt>.
 <p>

Simple defaults (for logonName=default):   <input  type="button" id="logonButton0" value="Logon"
              title="Test of Admin logon: simple defaults\nResults written to console.log()"   onClick="wsurvey.adminLogon()" >

 &boxV;
jQuery(#xx).on() (for logonName=default):
   <input  type="button" id="logonButton2" value="Logon"   title="Test  of Admin logon: .on() call" >
   
<br>

 in line (for logonName=dogName). Password should be <tt>fido</tt>):   <input  type="button" id="logonButton" value="Logon"   pwd=""
              logonName="dogMan" whenCall="0"  callbackLogon="test_logonCallback"
              title="Test of Admin logon: inline call"   onClick="wsurvey.adminLogon(this)" >

 <p>
   <input  type="button" id="logoffButton" value="logoff" title="results written with an alert()" onClick="wsurvey.adminLogon_logoff('','byebye')" >
   <input  type="button" id="extendButton" value="extend by 20"  title="results written with an alert()"  onClick="wsurvey.adminLogon_extend('20','','extending default!')" >

<hr>
Results here!
<div id="response1" style="margin:3px 3em 3px 3em;border:2px solid tan">...</div>

   <input  type="button" id="logoffButton" value="status"   onClick="checkStatus() " >


<div id="statusHere" style="margin:3px 3em 3px 3em;border:2px solid tan">...</div>


 <hr>

<div id="otherLogonBox" style="padding:3em;background-color:#efedea">

 In line, whenCall=1 (for logonName=default):
  show logon button   <input  type="button" id="logonButton" value="Logon"   pwd=""
              logonName="" whenCall="1"  callbackLogon="test_logonCallback_full"
              title="Test of Admin logon: whenCall=1"   onClick="wsurvey.adminLogon(this)" >


<div id="menu2" style="display:none;border:2px solid cyan;margin:3px 3em 3px 3em">
   Enter your password: <input type="text" value="" id="yourPassword"> and then
   <input type="button" value="Submit the password" onclick="submitPassword2(this)">
  </div>


<span id="results3" style="margin:3px 1em 3px 3em;background-color:yellow"></span>

<div id="response2" style="margin:3px 3em 3px 3em;border:2px solid brown">whenCall=1 arguments here!</div>

mylgon button!
</div>

</body>
</html>