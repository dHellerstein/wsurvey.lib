<?php
ob_start();
// Echoback files send from wsurvey.uploadFiles.echoback() (.js function)
// echoback uses a disposition response header.
// This causes most browsers to give the user the choice of viewing, or saving as a file, the contents of the response

 $acurdir=getcwd();
 $libdir=dirname($acurdir);                  // in non-demo code, set $getit to be wherever you stored  wsurvey.uploadFiles.php
 $getit=$libdir.'/php/wsurvey.uploadFiles.php';
 require_once($getit);

  $which=wsurvey\uploadFiles\extractRequestVar('which',0);
  ob_clean();
 $astuff0=wsurvey\uploadFiles\echoBack($which);    // echo  -- if multiple files, sends back a .zip
 exit;
