<?php
// Example of a wsurvey.adminLogon_params.php file
//
// This is read by wsurvey.adminLogon.php
// The defaults
$passwordActual="a";                   // Required. The "admin" password (it will be hashed when sent to server). It MUST be specified
$pwdDuration=30;                     // Default =2000. in milliseconds (pwd expires after this amount of time

$wsurveyadminLogon_params['dogMan']=   ['passwordActual'=>'fido', 'pwdDuration'=>45  ];

// for logonName specific values, add to wsurveyadminLogon_params['logonName']. For example:
//  For example:
//     $wsurveyadminLogon_params['dogMan']=   ['passwordActual'=>'fido35', 'pwdDuration'=>1500 ];
//     $wsurveyadminLogon_params['gallery']=  ['passwordActual'=>'a' ];

?>
