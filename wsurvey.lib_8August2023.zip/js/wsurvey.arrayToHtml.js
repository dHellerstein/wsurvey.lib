//============
// display as a big html table with column headers
// or ... adjust display of of existing table  (if called with 1 argument)
// Note: for an alternative, see the phpLib "divTable.php". Or wsurvey.sortTable
//
//
//
//   vv :
//        *  an "associative array"  -- a numbered array, each row is an object
//         A "table" of this array will be built

//   aopts: optional. If specifid, an object containing option values
//
// see wsurvey.arrayToHtml.txt for the details
//
//   returns:  [htmlTable,htmlTableId];
//         The htmlTable is a string containing the htmlTable. It can written to the browser window. I.e.;  $('#showResults').html(htmlTable) ;
//         The htmlTableId is a random string used as the ID of the "htmlTable".
//         It can be used to in the change Display mode (see below)
//
// -------------------------------------------


if (typeof(wsurvey)=='undefined')  {
    var wsurvey={};
}
wsurvey.arrayToHtml={};

//=============
// vv is an array of objects
//  each row  (vv[n]= {'index1':aval,..}
//   Rows typically, but are not required, to have the same "index" values

wsurvey.arrayToHtml.init=function(vv,aopts) {

   var allvars={},irow,avv,avar,amess='',arow,ii,vlist=[],ii2,sayval,totem=0,t1,j1,j2,doit=0;
   var icolor,colors=['tan','#abbaba','silver'],skipVars={},colHeader1='row',achar,tt,efoo2;
   var nFreeze,zid,useColor,efoo3,acolor,aval,aval0,sptype,colLabels={};
   var leftLabels,alabel,b1,b2,sayRow,atbleId,idir,ethis,doAddComma=0,nDec=0,nDecUse=0,cellWidth=5,newline,addWidth=5,startHeight=12;  // height in em
   var hiliteClass='0',cellWidthLookups={},acellWidth,useId=0;
   var titles={},ntitles;

   if (typeof(wsurvey.argJquery)!='function') {
       alert('wsurvey.arrayToHtml requires   wsurvey.utils1.js ');
       throw 'Missing .js file ';
   }

  wsurvey.arrayToHtml.createStyles(0)  ; // adds styles  (if don't exist) .. do this first (used by simulated table when computing width and height)

// ......... display vv (array of associative arrays) !
   let zid0=Math.random().toString(36).substring(2, 15) + Math.random().toString(36).substring(2, 15);   // assign an ID to this "table" -- something long and random to avoid name conflict

// begin parameters read section ........
   if (typeof(aopts['skipVars'])!=='undefined') {        // variables to NOT display
          avv=aopts['skipVars'].split(',');
          for (ii=0;ii<avv.length;ii++) {
              avar=jQuery.trim(avv[ii]);
              skipVars[avar]=1;
          }
   }

   if (typeof(aopts['nDec'])!=='undefined') {        // precision of numbers
           tt=jQuery.trim(aopts['nDec']);
           if (!isNaN(tt)) {
               nDec=parseInt(tt);
               nDecUse=1;
           }
     }

   if (typeof(aopts['id'])!=='undefined') {        // precision of numbers
           id=jQuery.trim(aopts['id']);
           if (id=='0' || id=='') {
               zid=zid0;
           } else {
               zid=id;
           }
    } else {
       zid=zid0 ;
    }

    if (typeof(aopts['ndec'])!=='undefined') {        //  synonym
           tt=jQuery.trim(aopts['ndec']);
           if (!isNaN(tt)) {
               nDec=parseInt(tt);
               nDecUse=1;
           }
    }

// default cell  = 5, with nothing col specific.
   if (typeof(aopts['cellWidth'])=='undefined' && typeof(aopts['cellWidths'])!=='undefined') aopts['cellWidth']=aopts['cellWidths'] ;  // a synonym

// # : width of col 1, * : width of unspecified columns
   if (typeof(aopts['cellWidth'])!=='undefined') {
       tt=aopts['cellWidth'];     // could be a single value, or an asscoative array of values (with * used as default)
       if (typeof(tt)=='object') {            //  col specific values?
              if  (tt.hasOwnProperty('*')) {  // set default?
                  let jtt=tt['*'] ;
                  if (!isNaN(jtt) && jtt>=1)  cellWidth=parseInt(jtt);  // default cell width (em) for indices with no match in cellWidthLookups
             }
             cellWidthLookups=tt;        // use object as is (after looking for a * index)
       } else {                              // single value used for all
           if (!isNaN(tt) && jQuery.trim(tt)!=='') {
               cellWidth=parseInt(jQuery.trim(tt));
           }
       }
   }

   if (typeof(aopts['hiliteClass'])!=='undefined') {        // higlight rows on click
           hiliteClass=jQuery.trim(aopts['hiliteClass']);
           if (hiliteClass!=='0') {  // 1 or '' are use default
               if (hiliteClass=='' || hiliteClass=='1') hiliteClass='wsurvey_arrayToHtml_rowHilite';
           }
     }

   if (typeof(aopts['addComma'])!=='undefined') {
           doAddComma=jQuery.trim(aopts['addComma']);
     }

   if (typeof(aopts['addWidth'])!=='undefined') {
           avv=jQuery.trim(aopts['addWidth']);
           if (!isNaN(avv) && avv>0) addWidth=parseInt(avv);
     }

    if (typeof(aopts['height'])!=='undefined') {
           avv=jQuery.trim(aopts['height']);
           if (!isNaN(avv) && avv>=1) {
               startHeight=parseFloat(avv).toFixed(1);    // miniumum of 1 em
           }
     }


   let nColLabels=0;
    if (typeof(aopts['colLabels'])!=='undefined') {     // do some error checking. ANd cound the numbe of col labels -- thats the max number of cloumns
           colLabels=aopts['colLabels'];
           let nn=0;
           for (let ba in colLabels) {
                nn++;
                if (ba.substr(0,1)==' ') {
                   wsurvey.arrayToHtml.error('column labels can NOT start with a  space: '+ba)   ;
                }
                nColLabels++;
           }
     }

    if (typeof(aopts['titles'])!=='undefined') {
           titles=aopts['titles'];
           for (let ba in titles)    ntitles++;
     }


   if (typeof(aopts['colors'])!=='undefined') {        // variables to NOT display
          avv=aopts['colors'].split(',');
          colors=[];
          for (iv=0;iv<avv.length;iv++) {
              acolor=jQuery.trim(avv[iv]);
              if (acolor!='')   colors.push(acolor);
          }
    }

   leftLabels={'top':'#'} ;
   if (typeof(aopts['leftColLabels'])!=='undefined') {
      if (typeof(aopts['leftColLabels'])=='string') {
        avv=aopts['leftColLabels'].split(',');
        for (iv=0;iv<avv.length;iv++) {
           alabel=jQuery.trim(avv[iv])+'=';  // force at least 2 elements
           if (alabel=='')  continue;
           avv2=alabel.split('=');
           b1=jQuery.trim(avv2[0]);
           b2=jQuery.trim(avv2[1]);
           leftLabels[b1]=b2;
        }
      } else {
        for (let vrr in aopts['leftColLabels']) leftLabels[vrr]=aopts['leftColLabels'][vrr];
      }
   }      // cellWidth['#'] sets width of first col

//   let w1=jQuery.trim(leftLabels['width']);
//   if (isNaN(w1) || w1=='') w1=2;
//   w1=Math.max(parseInt(w1),1.5);
//   leftLabels['width']=w1;

    colHeader1=leftLabels['top'];


   j1=0; j2=vv.length-1;                           // row range
   if (typeof(aopts['range'])!=='undefined') {
       arow=aopts['range']+',';
       avv=arow.split(',');
       t1=jQuery.trim(avv[0]);
       if (t1=='' || isNaN(t1)) t1=0;
       j1=parseInt(t1);
       t1=jQuery.trim(avv[1]);
       if (t1=='' || isNaN(t1)) t1=vv.length-1;
       j2=parseInt(t1);
   }

   nFreeze=0;
   if (typeof(aopts['freeze'])!=='undefined') {    // # of rows to freeze
       arow=aopts['freeze'] ;
       t1=jQuery.trim(arow);
       if (t1=='' || isNaN(t1)) t1=1;
       nFreeze=parseInt(t1);
   }

// END of parameters read
 
// extract rows from associative array ...

   for (irow=j1;irow<=Math.min(vv.length-1,j2);irow++) {                 // find all variables specified in the row range
       avv=vv[irow];
       for (avar in avv) {
           if (typeof(skipVars[avar])!=='undefined') continue ;   // matches a skipvars? Then ignore
           allvars[avar]=1;
       }
   }

// what columns to show (after remove of "skip vars"), and the labels, and in what order.
// if coLlabels not defined, use them all, with breaks at _ and .
   let arf=wsurvey.arrayToHtml.colLabels(allvars,colLabels,nColLabels) ;     // collabels is a "keep" -- keep if specified ('*'= keep all)
   let nlabels2=arf[0];
   if (nlabels2==0) {
          wsurvey.arrayToHtml.error(' changeDisplay error: the column labels do  NOT include ANY existing indices (in the array rows) ');
   }
   colLabels=arf[1];
   
 // first time -- to get absolute sizes (using absolute sizes avoids premature line breaks, without using infnitely wide container)
   amess='';
   icolor=0;

// create temporary elements ....

    let zid00=Math.random().toString(36).substring(2,10) ;
         let zidMain=zid+'_'+zid00+'_main';
       let zidHeader=zid+'_'+zid00+'_header';
   let zidHeaderLast=zid+'_'+zid00+'_last';

   amess+='<div class="wsurvey_arrayToHtml_main" style="width:7000em;" id="'+zidMain+'">';    // very wide so nothing wraps
   amess+='<div  class="wsurvey_arrayToHtml_colHeaderRow   " dtype="-1"  id="'+zidHeader+'" >';           // column headers  are an indepdent div

    acellWidth= (cellWidthLookups.hasOwnProperty('#')) ? cellWidthLookups['#'] : cellWidth ;

   amess+='<div class="wsurvey_arrayToHtml_topLeft" style="width:'+acellWidth+'em">'+colHeader1+'</div>';   // each col header is a div that is floated left -- start with "row numbr" col (leftmost)

   for (avar in colLabels) {
        if (avar.substr(0,1)==' ') continue;  // should never happen
       acellWidth= (cellWidthLookups.hasOwnProperty(avar)) ? cellWidthLookups[avar] : cellWidth ;
       amess+='<div class="wsurvey_arrayToHtml_colHeaderCell" varname="'+avar+'" style="width:'+acellWidth+'em;background-color:'+colors[icolor]+'" >'+colLabels[avar]+'</div>';
   }
   amess+='<div varname="ZZ" id="'+zidHeaderLast+'" class="wsurvey_arrayToHtml_colHeaderCell" style="width:'+addWidth+'em" > ZZ </div>';  // add a cell to right: temporary, used to figure out optimal cell widths

   amess+='</div>';        // colHeaderRow   temp
   amess+='<br clear="all"> ';
   amess+='</div>'              // main   temp

   amess+='<br clear="all">';

   jQuery(document.body).append(amess);;

   let efooZZ=jQuery('#'+zidHeaderLast);           // position of final cell (the "ZZ" cell)
   let rectLast=efooZZ[0].getBoundingClientRect()
   let totTableWidth=parseInt(rectLast['right']) ;

   let efooColH=jQuery('#'+zidHeader);
   efoo3=efooColH.find('.wsurvey_arrayToHtml_colHeaderCell');

   let iheight=0;   // height of column header row
   efoo3.each(function(idx){                          // find max height of the cells in the colHeader row
       iheight=Math.max(iheight,jQuery(this).height());
   })

// alert('colheader height '+totTableWidth+' x ' +iheight);
 // throw 3;

   jQuery('#'+zidMain).remove();              // remove the temporary copy (used only to read actual size, that is used below)

// !!!  start making the final table !!
//       Redo with absolute sizes computed using the  temporary 'write colHeader row's content, and then read size and position"  done above

   amess='';   vlist=[];
   amess+='<div  class="wsurvey_arrayToHtml_main" style="width:'+totTableWidth+'px"  id="'+zid+'">';      // col header, no scrolliing, and scrollingg rows container

   amess+='<div class="wsurvey_arrayToHtml_colHeaderRow" dtype="-2"   >';           // column headers
   acellWidth= (cellWidthLookups.hasOwnProperty('#')) ? cellWidthLookups['#'] : cellWidth ;  // use col specific widh, or generic one.

   let colHeader1T=wsurvey.removeAllTags(colHeader1)
   amess+='<div  varname="'+colHeader1T+'"  class="wsurvey_arrayToHtml_topLeft "  style="width:'+acellWidth+'em"  >'+colHeader1+'</div>';   // each header is a div that is floated left
   var colj=0;

   for (avar in colLabels) {          // write the array-index values as column headers (splitting long names)
         vlist.push(avar);           // list of columns to display (used below)
         acellWidth= (cellWidthLookups.hasOwnProperty(avar)) ? cellWidthLookups[avar] : cellWidth ;
         let atitleZ=wsurvey.removeAllTags(titles[avar]);
         if (titles.hasOwnProperty(avar)) {
            amess+='<div class="wsurvey_arrayToHtml_colHeaderCell" colJ="'+colj+'" title="Variable: '+avar+'&#013; &#149; '+atitleZ+'"  ';
            amess+='     varname="'+avar+'"  style="width:'+acellWidth+'em;height:'+iheight+'px">'+colLabels[avar]+'</div>';       // fill up the row
         } else {
            amess+='<div class="wsurvey_arrayToHtml_colHeaderCell" colJ="'+colj+'" title="Variable: '+avar+'" varname="'+avar+'"  style="width:'+acellWidth+'em;height:'+iheight+'px">'+colLabels[avar]+'</div>';       // fill up the row
         }
         colj++;
   }
   amess+='</div>';         // column headers
   amess+='<br clear="all">';

  let c1Width= (cellWidthLookups.hasOwnProperty('#')) ? cellWidthLookups['#'] : cellWidth ;
  for (irow=j1;irow<Math.min(vv.length,j1+nFreeze);irow++)  {        // the NON SCROLLING ROWS   ==================
     arow=vv[irow];
     icolor=0; useColor=colors[icolor];
     amess+='<div title="Row '+irow+'" class="wsurvey_arrayToHtml_noScrollRow"  data-rowct="'+irow+'" style="background-color:'+colors[icolor]+'" >';           // a non scrolled rows

     if (leftLabels.hasOwnProperty(irow)) {
         sayRow=leftLabels[irow];
     } else if (leftLabels.hasOwnProperty('*') ) {
         sayRow=leftLabels['*'];
     } else {
        sayRow=irow;
     }

     let sayRowTitle0=wsurvey.removeAllTags(sayRow);
     amess+='<div dog="fido" class="wsurvey_arrayToHtml_left1 " style="background-color:'+useColor+';width:'+c1Width+'em" >';
     amess+='<span title="Frozen row: '+sayRowTitle0+'">'+sayRow+'</span></div>';
     for (ii2=0;ii2<vlist.length;ii2++) {
          avar=vlist[ii2];
          if (typeof(arow[avar])=='undefined'){      // no explicit value for this column in this row
               acellWidth= (cellWidthLookups.hasOwnProperty(avar)) ? cellWidthLookups[avar] : cellWidth ;
               amess+=' <div class="wsurvey_arrayToHtml_rowCell " colj="'+ii2+'" dtype="1" style="width:'+acellWidth+'em;background-color:'+useColor+'" >';
               amess+=' <span isValSpan="0"   varname="'+avar+'" title="'+avar+' not specified in this row">&hellip;</span></div> ';

          } else {                                  // specifided in this row
             aval0=arow[avar] ;
             if (jQuery.isArray(aval0)){      // got an explicit value?
                aval=aval0[0]; sayval=aval;
                if (aval0.length>1) sayval=aval0[1];
             } else {                             // use value as is -- perhaps with commas and decimal precision (if number)
                aval=aval0;
                if (!isNaN(aval)) {
                   if (nDecUse==1) aval=aval.toFixed(nDec);
                   if (doAddComma==1) aval=wsurvey.addComma(aval);
                }
                sayval=aval;
             }                                // explicit, or not, display value
            acellWidth= (cellWidthLookups.hasOwnProperty(avar)) ? cellWidthLookups[avar] : cellWidth ;
            let avalTitle2=wsurvey.removeAllTags(aval);
            let aval64=btoa(aval);

            amess+='<div  class="wsurvey_arrayToHtml_rowCell " colj="'+ii2+'"   dtype="2" style="width:'+acellWidth+'em;background-color:'+useColor+'" >';
            amess+='  <span  isValSpan="1" varname="'+avar+'" title="'+avar+': '+avalTitle2+'" data-arraytohtml="'+aval64+'">'+sayval +'</span></div> ';
          }         // missing
      }             // eachcell
      amess+='</div>';        // non scrolled row
      amess+='<br clear="all">';
  }               // end of NON SCROLLIGN ROWS    =====================



//  return [amess,zid];
// start of scrolled rows ==========================
  amess+='<div  class="wsurvey_arrayToHtml_scrollRows" style="height:'+startHeight+'em">';     // containter for all the srolled rows (this has a y scrollbar, but NOT x)

  for (irow=j1+nFreeze;irow<=Math.min(vv.length-1,j2);irow++)  {
     arow=vv[irow];
     icolor++; if (icolor>=colors.length)icolor=1 ;
      useColor=colors[icolor];
     amess+='<div title="Row '+irow+'" class="wsurvey_arrayToHtml_aScrollRow" data-rowct="'+irow+'" style="background-color:'+useColor+'" >';           // containter for a   scrolled row

     if (leftLabels.hasOwnProperty(irow)) {
         sayRow=leftLabels[irow];
     } else if (leftLabels.hasOwnProperty('*') ) {
         sayRow=leftLabels['*'];
     } else {
        sayRow=irow;
     }

      acellWidth= (cellWidthLookups.hasOwnProperty('#')) ? cellWidthLookups['#'] : cellWidth ;
//alert('ooga '+acellWidth);
      amess+='<div dog="rover" class="wsurvey_arrayToHtml_left1 wsurvey_arrayToHtml_left1Scroll "  style="background-color:'+useColor+';width:'+acellWidth+'em" ';

     acellWidth= (cellWidthLookups.hasOwnProperty('#')) ? cellWidthLookups['#'] : cellWidth ;
     if (hiliteClass!=='0') {
         amess+=' data-hiliteclass="'+hiliteClass+'" onClick="wsurvey.arrayToHtml.hilite(this)"  ';
         amess+='>';
         let sayRow2=irow;
         amess+=' <span   class="wsurvey_arrayToHtml_hiliteRowButton" title="Click to highlight this row: '+sayRow2+'">'+sayRow+'</span></div>';
     } else {
         amess+='>';
         let sayRowTitle=wsurvey.removeAllTags(sayRow) ;
         amess+=' <span   title="'+sayRowTitle+'">'+sayRow+'</span></div>';
     }
     for (ii2=0;ii2<vlist.length;ii2++) {
           avar=vlist[ii2];
           if (typeof(arow[avar])=='undefined'){       // no such index in this row
                acellWidth= (cellWidthLookups.hasOwnProperty(avar)) ? cellWidthLookups[avar] : cellWidth ;
                amess+=' <div class="wsurvey_arrayToHtml_rowCell "  colj="'+ii2+'"  dtype="3" style="width:'+acellWidth+'em;background-color:'+useColor+'">';
                amess+='<span  isValSpan="0"   varname="'+avar+'"  title="'+avar+' not specified in this row">&hellip;</span></div> ';
           } else {
              aval0=arow[avar] ;
              if (jQuery.isArray(aval0)){      // got an explicit value?
                  aval=aval0[0]; sayval=aval;
                  if (aval0.length>1) sayval=aval0[1];
              } else {                             // use value as is -- perhaps with commas and decimal precision (if number)
                aval=aval0;
                if (!isNaN(aval) && typeof(aval.toFixed)=='function') {   // catch some odd constructions
                   if (nDecUse==1) aval=aval.toFixed(nDec);
                   if (doAddComma==1) aval=wsurvey.addComma(aval);
                }
                sayval=aval;
              }   // isarray
              acellWidth= (cellWidthLookups.hasOwnProperty(avar)) ? cellWidthLookups[avar] : cellWidth ;
              let avalTitleC=wsurvey.removeAllTags(aval0);

              let aval64C=btoa(aval);
              amess+='<div  class="wsurvey_arrayToHtml_rowCell "  colj="'+ii2+'" dtype="4"  style="width:'+acellWidth+'em;background-color:'+useColor+'" >';
              amess+='<span isValSpan="1"  varname="'+avar+'" title="'+avar+': '+avalTitleC+'" data-arraytohtml="'+aval64C+'">'+sayval +'</span></div> ';
           }                // typeof(arow[avar]=undefined
      }      // the COLUMNS  vlist.length;
      amess+='<br clear="all">';

      amess+='</div>';   //    this row of float:left divs

  }        //   END OF  of scrolled rows ==========================    scrolled fow

  amess+='<div style="background-color:'+colors[0]+'"> &hellip; </div>';// spacer at bottom
  amess+='</div> ' ;          // block of srolled rows END

  amess+='</div>'  ;

  return [amess,zid];

}

//============================
// click handler to highlight a row
wsurvey.arrayToHtml.hilite=function(athis) {
   var e1=wsurvey.argJquery(athis);
   var hclass=e1.attr('data-hiliteclass');
   if (hclass===false) return 0;       // should never happen
   var eparent=e1.closest('.wsurvey_arrayToHtml_main');
   var e2=eparent.find('.wsurvey_arrayToHtml_aScrollRow');

   e2.removeClass(hclass);
   var e3=e1.closest('.wsurvey_arrayToHtml_aScrollRow');
   e3.addClass(hclass);
   return 0;
}


//=----------------------------   colLabels vlist

// helper funcdtion create column labels, or check existing
wsurvey.arrayToHtml.colLabels=function(allvars,colLabels,nColLabels) {
   var avar,daval,allClass='';doAll=0,nlabels=0;

  if (nColLabels ==0) {               // no column labels specified.
      for (avar in allvars) {
          daval=wsurvey.arrayToHtml.colLabels2(avar);
          colLabels[avar]=daval ;
          nlabels++;
      }
      return [nlabels,colLabels];
  }
// else remove from colLabels if no such var; or use variable name as label if empty

  for (avar in colLabels) {
    if (avar=='*') {
       allClass=jQuery.trim(colLabels[avar]);
       doAll=1;
       delete colLabels[avar];
       continue;
    }
    if (typeof (allvars[avar])=='undefined') {     // no such variable, remove it  from colLabels list
      delete colLabels[avar];
      continue;
    }

    nlabels++;
    daval=jQuery.trim(colLabels[avar]);
    if (daval=='') {          // no explicit label? prettify column name!
         daval=wsurvey.arrayToHtml.colLabels2(avar);
         colLabels[avar]=daval;     // change in place
     }
  }

// add "non specified" at end?
  if (doAll==0) return [nlabels,colLabels];   // do NOT add "non specified" columns

  for (avar in allvars) {
     if (typeof(colLabels[avar])!=='undefined') continue;
     daval=wsurvey.arrayToHtml.colLabels2(avar);
     if (allClass!=='') daval='<span class="'+allClass+'">'+daval+'</span>';
     colLabels[avar]=daval ;
     nlabels++;

  }

  if (typeof(colLabels['*'])!=='undefined') delete colLabels['*'];  // cl;eanup
  return [nlabels,colLabels];

}

//============
//  helper funcdtoin: break up long name into several lines (break on . or _  or upperCase (in camelback)
wsurvey.arrayToHtml.colLabels2=function(avar) {
   var ii,achar,tt,newline=1,tt=[];
   for (ii=0;ii<avar.length;ii++) {                  // break on _ or uppercase
      achar=avar.substr(ii,1);
      if (achar=='_'  ||   achar==achar.toUpperCase()  ) {       // a break. Note that ., or any non-character, is a break
         if (newline==1)   {        // newline JUST done -- don't have two in a row
            tt.push(achar);   // don't repeat a new line
          } else {                 // make a new line...
            tt.push('<br>');
            tt.push(achar);
            newline=1;
          }
      } else {
         tt.push(achar);
         newline=0;
      }    // done with this char
   }
  avar=tt.join('');
  return avar;
}

//================
// add click handler
wsurvey.arrayToHtml.clickHandler=function(aid,afunc) {
   var e1,e2;
   e1=wsurvey.argJquery(aid);
   if (e1.length==0){
      wsurvey.arrayToHtml.error('click handler error: no such tableid: '+aid);
      return 0 ;
   }
   if (typeof(afunc)=='string') {
       if (typeof(window[afunc])!='function') { 
                wsurvey.arrayToHtml.error('click handler error: no such function ('+afunc+') for use with table '+aid+')');
       }
       afunc=window[afunc];
   } else {
       if (typeof(afunc)!='function') {
          wsurvey.arrayToHtml.error('click handler error: no such function (for use with table '+aid+')');
       }
    }

    e1.on('click',{'tocall':afunc},wsurvey.arrayToHtml.clickHandler2);
    return 1;
}

/// ============= called on click .. willl call user supplied function
wsurvey.arrayToHtml.clickHandler2=function(evt) {

  var  adata=evt.data;
  var afunc=adata['tocall'] ;        // assigned to event handler (parent of a cell that was clicked on)

  let e1=wsurvey.argJquery(evt);
  let ss=e1.attr('isvalspan');
  if (ss===null || typeof(ss)=='undefined' ) {  // check that the clicked element is a "table cell span". Might have to go back to closest<span>
      let e12=e1.closest('[isvalspan]');

      if (e12.length==0) return 0 ; // not table cell
      e1=e12;
      ss=e1.attr('isvalspan');
  }

  let origVal=null;
  if (ss==1) origVal=atob(e1.attr('data-arraytohtml'));
  let varname=e1.attr('varname');
  let e2=e1.closest('.wsurvey_arrayToHtml_aScrollRow,.wsurvey_arrayToHtml_noScrollRow');
  let irow=e2.attr('data-rowct');
  afunc(irow,varname,origVal,e1);

}

//========================
// change display of existing arrayToHtml table
wsurvey.arrayToHtml.display=function(evt,action,option)  {
  var ethis=wsurvey.argJquery(evt);
  var etable;
 
  if (ethis.length==0) {
        wsurvey.arrayToHtml.error('display: unable to find id (for '+evt+')')
        throw 'display error';
  }
  if (arguments.length==1)  {  // a click handler
     action=ethis.wsurvey_attr(':action,data-action,action','rows',1);
     option=ethis.wsurvey_attr(':option,data-option,option','12',1);
     etable=wsurvey.arrayToHtml.cousin(ethis );
     if (etable===false)  wsurvey.arrayToHtml.error('display: unable to find a arrayTable (as a .cousin, using .wsurvey_arrayToHtml_main) ');
  } else {
     etable=ethis;
     if (!etable.hasClass('wsurvey_arrayToHtml_main'))   wsurvey.arrayToHtml.error('display: not an an arrayToHtml table: '+evt);
  }
  let atry=jQuery.trim(action).toLowerCase().substr(0,3)   ;
  if (atry=='row' || atry=='cha') {
       option=jQuery.trim(option);
       if (isNaN(option) || option=='') option=12;  // 12 px increase if wierd
       option=parseInt(option);
       let escrolls=etable.find('.wsurvey_arrayToHtml_scrollRows');
       if (escrolls.length==0)   wsurvey.arrayToHtml.error('display: unable to find a scroll portion of an arrayToHtml table ');
       let rectLast=escrolls[0].getBoundingClientRect();
       let aheight=rectLast['height'];
       let newHeight=Math.max(24,aheight+option );  // could be + or - can't ge less than 24 px
//       alert(aheight+' new height '+newHeight);
       escrolls.height(newHeight);
  }
  if (atry=='cel' || atry=='wid') {
       if (isNaN(option) || option=='') option=6;
       let pxAdded=0;

       option=parseInt(option);
       eAllCellsH=etable.find('.wsurvey_arrayToHtml_colHeaderCell');
       for (var i1=0;i1<eAllCellsH.length;i1++) {
           let ae1=eAllCellsH[i1];
           let arec=ae1.getBoundingClientRect();
           let awidth=arec['width'];
           newwidth=awidth+option ;
           if (newwidth>20) {       // if resize makes it too nrrow, don't do
              pxAdded+=option;
              let ee1=$(ae1);
              ee1.width(newwidth);
           }
       }
       let eAllCells=etable.find('.wsurvey_arrayToHtml_rowCell');
       for (var i1=0;i1<eAllCells.length;i1++) {
           let ae1=eAllCells[i1];
           let arec=ae1.getBoundingClientRect();
           let awidth=arec['width'];
           newwidth=awidth+option ;
           if (newwidth>20) {
             let ee1=$(ae1);
             ee1.width(newwidth);
           }
       }

       let orect=etable[0].getBoundingClientRect();
       let owidth=orect['width'];
       let newOwidth=owidth+pxAdded;
       etable.width(newOwidth);
  }


}



//=============
// find sibling, or sibling of a parent, that is an arrayToHtml table (has a wsurvey_arrayToHtml_main class)
wsurvey.arrayToHtml.cousin=function(ethis,whatCheck) {
   if (arguments.length<2) whatCheck='.wsurvey_arrayToHtml_main';

   let eparent=ethis.parent();
   let tagP=eparent.prop('tagName').toLowerCase();

//alert('in relative '+whatCheck+' :: '+ eparent.prop('tagName'));

  if (eparent.hasClass('wsurvey_arrayToHtml_main')) return eparent ;  // this is inside of a arrayToHtml table (could occur with careful coding)

  let esib=eparent.find(whatCheck);
  if (esib.length>0) return $(esib[0]);    //a sibling (of this parent) found  -- return first one

  if (tagP=='body') return false ;      // top of tree, can't look no more
  let aa=wsurvey.arrayToHtml.cousin(eparent,whatCheck);  // recurse...
  return aa;
}

//===========================
// add and subtract # of "scrollable rows" to view
wsurvey.arrayToHtml.changeRows=function(iadd,aid) {
  var eid,e2,iheight;
   eid=wsurvey.argJquery(aid);                                // existence was checked for by caller
   e2=eid.find('.wsurvey_arrayToHtml_scrollRows');
   iheight=e2.height();
   iheight=(1+(iadd/10))*iheight;
   iheight=Math.max(iheight,20);
   e2.height(iheight);

}

//==========================
// return array of column headers
wsurvey.arrayToHtml.getVars=function(aid) {
  var eid,e2,e3,evars=[];
   eid=wsurvey.argJquery(aid);
   e2=eid.find('.wsurvey_arrayToHtml_colHeaderRow');
   e3=e2.find('div');
   e3.each(function(ix) {
      e3a=jQuery(this);
      evars.push(e3a.attr('varname'));
   });
   return evars;
}


//=--------------
// change cell widthx
wsurvey.arrayToHtml.cellWidth=function(aid,idir) {
  var eid,e2,e3,iwidth;
   eid=wsurvey.argJquery(aid);
   e2=eid.find('.wsurvey_arrayToHtml_colHeaderCell,.wsurvey_arrayToHtml_rowCell');
   e3=jQuery(e2[0]);
   iwidth=e3.width();
//   alert(e2.length+' LLL '+iwidth+' ' +idir);
   iwidth=iwidth+(idir*10);
   e2.width(iwidth);
}

//===============
// select which columns to view
wsurvey.arrayToHtml.viewVars=function(aid,varlist) {
  var eid,e2,e3,evars={},avar,vs,iv,bvar,colKeep=[],ikeep;
  var icol,ido,eact,arf,varlistAll=[];

   eid=wsurvey.argJquery(aid);
   e2=eid.find('.wsurvey_arrayToHtml_colHeaderRow');
   e3=e2.find('div');

   e3.each(function(ix) {      // get list of all column names
      e3a=jQuery(this);
      avar=jQuery.trim(e3a.attr('varname')).toUpperCase();
      varlistAll.push(avar);
      colj=e3a.wsAttr('colj',-1);
      if (colj>0) {
          evars[avar]=e3a.wsAttr('colj',0);
          colKeep[colj]=0;                  // default is to remove
      }
   });
 
   if (varlist=='*') {
      vs=varlistAll;
    } else {
       vs=varlist.split(',');         // the column names to keep
    }
   for (iv=0;iv<vs.length;iv++) {
     bvar=jQuery.trim(vs[iv]).toUpperCase();
     if (typeof(evars[bvar])!='undefined') {   // if a column to keep exists, mark as keep
         ikeep=evars[bvar];
         colKeep[ikeep]=1;
     }
   }
  for (icol in colKeep) {
     ido=colKeep[icol];
     if (typeof(ido)=='undefined') continue;   // if col 0
     arf='[colj="'+icol+'"]' ;
     eact=eid.find(arf);
     if (ido==1) {
        eact.show();
     } else {
       eact.hide();
     }
  }



}

//============
// special case  -- 10 feb 2022: needs fixing
/*
wsurvey.arrayToHtml.special1=function(athis) {

     if (arguments.length<2) {
          wsurvey.arrayToHtml.error(' click handler error: no tableid ');
          return 0;
    }
    wsurvey.arrayToHtml.clickHandler(vv,aopts);    // aopts is  the id of the table)... this presumes a prior call to wsurvey_arrayToHtmlTble
    return 1 ;
 }

// special cases. Note the addition of the SPECIAL option if call with just one argument.
 if (typeof(aopts['SPECIAL'])!=='undefined') {
     if (typeof(vv)!=='object') {       // should never happen
          wsurvey.arrayToHtml.error('changeDisplay error: first argument must be object (a pointer to the clicked element)');
     }
     if (typeof(vv.target)!=='undefined') {
         ethis=jQuery(vv.target);
     } else {
         ethis=jQuery(vv);
     }
      atableId=aopts['tableId'];
      if (typeof(atableId)==='undefined')  atableId=ethis.wsAttr('tableId',false);
      if (atableId===false) {
          wsurvey.arrayToHtml.error('changeDisplay error: no tableId attribute on 1 argument call');
      }
      if (jQuery('#'+atableId).length==0) {
          wsurvey.arrayToHtml.error('changeDisplay error: no such element with id=' +atableId);
      }
      doit=aopts['action'];
      if (typeof(doit)==='undefined')  doit=ethis.wsAttr('action','');
      doit=jQuery.trim(doit).toUpperCase();

      if (doit=='') {
         wsurvey.arrayToHtml.error('changeDisplay error: no action specified ');
         return '';
      }

     if (doit=='CHANGEROWS') {                    //  increase or decrease size of scrolleable rows container
         idir=aopts['DIRE'];
         if (typeof(idir)==='undefined')  idir=ethis.wsAttr('DIR',1);
          wsurvey.arrayToHtml.changeRows(idir,atableId);
          return 1 ;
      }
      if (doit=='GETVARS') {                    //  return array of variables
           avv=wsurvey.arrayToHtml.getVars(atableId);
           return avv ;
      }
      if (doit=='VIEWVARS') {                    //  return array of variables
          avv=aopts['varList'];
          if (typeof(avv)==='undefined')  avv=ethis.wsAttr('varlist','*');
          tt=wsurvey.arrayToHtml.viewVars(atableId,avv);
         return tt;
      }
      if (doit=='CELLWIDTH') {                    //  return array of variables
          idir=aopts['DIRE'];
          if (typeof(idir)==='undefined')  idir=ethis.wsAttr('DIR',1);
           tt=wsurvey.arrayToHtml.cellWidth(atableId,idir);
           return tt;
      }

      return 0    ;  // no known action
   }      // done with change display mode
 }
 */

//=============
// create styles usesd by arrayToHtml (if not already created)
wsurvey.arrayToHtml.createStyles=function(e1) {

  let ee=document.querySelector('[name="wsurveyarrayToHtml_defaults"]');

  if (ee!==null) {
    if (ee.getAttribute('data-autocreate') ==null) {
       console.log('Using custom version of wsurveyarrayToHtml_defaults  (css style sheet)');
    }
    return 1;  // already exists, do nothign
  }

  let dd=Date.now();

  let astring='.wsurvey_arrayToHtml_main {white-space:nowrap; overflow:auto; border:1px dotted  gray;} ';
  astring+='.wsurvey_arrayToHtml_colHeaderRow {color:blue; background-color:#abbaab;}   ';

  astring+='.wsurvey_arrayToHtml_topLeft { width:3em;  overflow:hidden;  font-style:oblique;  float:left;  background-color:#abbaab;}  ';
  astring+='.wsurvey_arrayToHtml_left1 { width:3em;  overflow:hidden;  font-style:oblique;  float:left;  background-color:#abbaab;}  ';
  astring+='.wsurvey_arrayToHtml_colHeaderCell {float:left; margin-right:5px;width:5em;min-height:1.1em;overflow:hidden;background-color:#abbaab;text-overflow:ellipsis; } ' ;

  astring+='.wsurvey_arrayToHtml_rowCell {margin-right:5px;   width:5em;   min-height:1.1em;   overflow:hidden; float:left;  background-color:#abbaab; text-overflow:ellipsis;}  ';
  astring+='.wsurvey_arrayToHtml_scrollRows {  margin-top:8px;  height:12em;  overflow-y:auto;  border:2px dotted #dbabab ;}  ';
  astring+='.wsurvey_arrayToHtml_noScrollRow { margin-bottom:3px;  }  ';
  astring+='.wsurvey_arrayToHtml_aScrollRow {   margin-bottom:3px;}  ';
  astring+='.wsurvey_arrayToHtml_rowHilite {   border:2px dotted blue !important ;padding-bottom:0.3em;   margin:0.5m 3px 0.5em 3px  !important;   color:#3333ff  !important ;}  ';
  astring+='.wsurvey_arrayToHtml_hiliteRowButton {color:#3333ff  !important ;   border-bottom:1px dotted blue !important ;}  ';

  jQuery('<style  data-autocreate="'+dd+'" name="wsurveyarrayToHtml_defaults" >').prop("type","text/css").html(astring).appendTo("head");

  console.log('Creating wsurveyarrayToHtml_defaults (css style sheet)');

return 1;
}


//============
// error handler
wsurvey.arrayToHtml.error=function(amess,quiet) {
   if (arguments.length<2) quiet=0 ;
   amess='wsurvey.arrayToHtml error: ' +amess;
    if (quiet!=1) alert(amess);
    console.trace(amess);
    throw 'wsurvey.arrayToHtml error ';
    return 0 ;
}        // end of wsurvey.resizer.abort

