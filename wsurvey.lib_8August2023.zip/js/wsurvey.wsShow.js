// 11 Apr  2023.
//
// show/hide container wsSurvey javascript library.
//
//   wsurvey.wsShow.init : initialize a container (with attributes used by wsShow)
//   wsurvey.wsShow.show  : show a container
//   wsurvey.wsShow.hide  : show a container
//   wsurvey.wsShow.hideRecent : hide most recently show container (shown using wsurvey.wsShow.show()  )
//   wsurvey.wsShow.inFront :  move to front, or back, a container (relative to wsurey.wsShow.show() containers)
//
//
// * Quick useage:
//     wsurvey.wsShow.init('#myBox',{options})
// ...
//    wsurvey.wsShow.show('#myBox')
//
//    wsurvey.wsShow.hide('#myBox')...
//
// Or, more commonly: event handlers are assigned to buttons that call .show (or .hide)
//
// For details, see wsurvey.wsShow.txt

if (typeof(window['wsurvey'])=='undefined') window['wsurvey']={};
wsurvey.wsShow={};

//=====================
// intialize a container that may be the "target" of a wsShow action (show,hide,esc,tofront)
//
// if not nitialized, the first call to .show  will attempt an initialization,
// by calling wsurvey.wsShow.init with no uoptions
//
// .init stores information in the elements $(aid).data(wsShow)
// and in $(document).data(wsShowAll)


wsurvey.wsShow.init=function(aid,uoptions) {

  let e1=$(aid)  ;
  if (e1.length==0) {
      alert('wsShow.init error: no such element: '+aid);
      return 0 ;
 }
  if (e1.length>1) {
      alert('wsShow.init error: more than one ('+e1.length+') matching elements '+aid);
      return 0 ;
 }

  if (arguments.length<2) uoptions={};  // use defaults, or try to read from attributes

  uoptions['target']=e1;   // not currently used ... but wth

// valid options (with defaults)
// If an options is NOT specified (case insensitive) in uoptions
//   1) a data-wsshow_optname attribute is used (if it exists)
//   2) if not, the default (in defOpts) is used
//
// Options recognized (case insensitive)
//   noesc : if 1, then target is NOT included in "esc to close" list (when opened)
//   nofront: if 1, then   target is NOT  included in   "move to front (or back)  " list
//   notoggle: if 1, then do NOT toggle show/hide (on consecutive calls to wsShow.show()
//   double: # of milliseconds lapse between clicks ... less than its considered to be a double click.
//           0 to disable double click (hence disable send to back)
//  fadein : if >0, fadein when opening (in milliseconds). 0 means no fadein  (just .show())

 let defOpts={'noesc':0,'nofront':0,'notoggle':0,'fadein':0,'double':500 } ;   // don't include target in this list
 let gotOpts={'noesc':0,'nofront':0,'notoggle':0,'fadein':0,'double':0}  ;
 let eTarget=false;

 for (let aopt in uoptions) {
    let bopt=jQuery.trim(aopt).toLowerCase()  ;
    if (!defOpts.hasOwnProperty(bopt)) continue ;  // unrecognized option

    let vv=jQuery.trim(uoptions[aopt]) ;

    if (bopt=='fadein') {              //fadein is special
       if (!jQuery.isNumeric(vv) || vv<0) vv=0;
       defOpts[bopt]=vv;
       gotOpts[bopt]=1;
       continue;
   }
   if (bopt=='double') {              //double is special
       if (!jQuery.isNumeric(vv) || vv<0) vv=0;
       defOpts[bopt]=vv;
       gotOpts[bopt]=1;
       continue;
   }


    if (vv===false || vv===true) {   // yes/no options
       defOpts[bopt]=vv;
    } else {
        vv = (jQuery.trim(vv)=='0')  ? false : true ;
        defOpts[bopt]=vv;
    }
    gotOpts[bopt]=1;
 }

  for (let bb in gotOpts) {        // not in uoptions? Perhaps its defined as an attribute
     if (gotOpts[bb]==1) continue;
     let vv2=e1.wsShowAttr('data-wsshow_'+bb,defOpts[bb]);
     if (bb=='fadein' || bb=='double') {
        if (!jQuery.isNumeric(vv2) || vv2<0) vv2=0;
     }   else {
        vv2 = (jQuery.trim(vv2)=='0')  ? false : true ;
     }
     defOpts[bb]=vv2;
 }

 let foo=jQuery.trim(Math.random());
 defOpts['id']=foo.substr(3,8);     // an arbitrary id, used to work with wsShowAll

 defOpts['lastClick']=0 ;
 e1.data('wsShow',defOpts);

 if (typeof($(document).data('wsShowAll')) =='undefined')  {    // used to track "open" containers
     let tt1={'zIndex':{},'lastShow':{},'lastClick':0};
     $(document).data('wsShowAll',tt1);
 }
 
 return 1 ;


}  // end of .init

// ==== synonymm

//====================================
// "show" a container (or possibly toggle)
//  modes:
//   aid has  a data(wsShow)  -- use its .data(wsShow)
//   aid does not have
//     a) check for a  data-wsshow -- which signals this is a "button" to open a specified target
//        The target is then used in a call to wsShow.show()!
//     b) does NOT have a data-wsshow attribute -- then "initialize" this (using attributes only)
// forceShow is optional. It is used only if the elment is already visible
// If specified:
//   0 : use the notoggle uoption
//   1:  toggle (ignore notoggle)
//   2:   show (ignore notoggle)
// returns 0 if now hidden, 1 if now shown

wsurvey.wsShow.show=function(aid,forceShow) {

   if (arguments.length<2) forceShow=0;
   if (!jQuery.isNumeric(forceShow)) {
      if (typeof(forceShow)=='string')  {
          let a2=jQuery.trim(forceShow).toLowerCase();
          forceShow=0;  //d efualt is use notoggle option
          if (a2=='toggle') forceShow=1   ;
          if (a2=='show') forceShow=2    ;
      } else {          // nto a string -- and not logical true?
        if (forceShow!=true)  forceShow=0;
      }
   }

   let e1=wsurvey.wsShow.argJquery(aid);
   if (e1===false) {
      if (typeof(aid)=='string') {    // try prepending a '#'
          aid='#'+aid;
          e1=wsurvey.wsShow.argJquery(aid);
       }
   }

   if (e1===false || e1.length==0) return false ; // an error

   let nowTime=Date.now();
   if (typeof(e1.data('wsShow'))=='undefined')   {  // this has not been initialized... perhaps its a button
      let abutton=e1.wsShowAttr('data-wsshow',false);
      if (abutton===false || jQuery.trim(abutton)=='')   {  // not a button -- so initialize this and then show it
         let q1=wsurvey.wsShow.init(aid) ;         // this forces creation of data(wsShow) for the element to show/hide
         if (q1===0) return 0;            // problem initializing (init showed an error alert
         let xx=wsurvey.wsShow.show(aid,forceShow);   //  now it can be dealt with (wsShow.init() added .data(wsShow)
         return xx;
      }   // else, is a button -- use its target

// perhaps this is a double click on a button?
      let lastClick=0;
      if (typeof(e1.data('lastClick'))!=='undefined')  lastClick=e1.data('lastClick');
      e1.data('lastClick',nowTime);
      mSec=nowTime-lastClick ;
      let doubleM=500  ;    // set to 500 milliseconds
      let qDouble= (mSec<doubleM) ? true : false ;  // double click?

      if (qDouble) abutton=e1.wsShowAttr('data-wsshow_alt',abutton);      // use alt if is specifed... if not, just use data-wsshow
      let xx=wsurvey.wsShow.show(abutton,forceShow)   ;   // pretend its a direct call using data-wsshow (or data-wsshow_alt) as the aid
      return xx;
   }        // else, initialized (by .init() or first call to .show()


   let wsShow=e1.data('wsShow');    // must be initialized if one is here!

   let isVis=e1.is(':visible');
   let notoggle=wsShow['notoggle'];
   if (forceShow!=0) {
      if (forceShow==1) notoggle=0;   // toggle NOT suppressed
      if (forceShow==2) notoggle=1;    // suppress togle -- hence: show (do NOT toggle off)
   }
   if (isVis) {
      if  (notoggle==0) {   // visible, suppress toggle NOT enabled -- so hide
        let xx=wsurvey.wsShow.hide(aid) ;
        return xx;
      }
   }
   if (!isVis) {           // not visible... so show it!
      if (wsShow['fadein']<=0) {
        e1.show();                         // show it!
      } else {
        e1.fadeIn(wsShow['fadein']);
      }
   }

// now record in esc and zindedx list -- or remove if no longer visible

   let wsShowAll=$(document).data('wsShowAll');
   if (typeof(wsShowAll)=='undefined')  {  // shouldn't happen, but wth
      wsShowAll={'zIndex':{},'lastShow':{},'lastClick':0};
   }
   let zid=wsShow['id'];   // internal id of this "shown" element
   let lastShow=wsShowAll['lastShow'];

   let aidSay= (typeof(aid)=='string') ? aid : '....' ;

   if (wsShow['noesc']!=1)  {   // include in lastShow list (if not already there)
      let astart = Date.now();
      let oof=[astart,e1,aidSay];
      lastShow[zid]=oof;      ; // timestamp with e1
      wsShowAll['lastShow']=lastShow;
   }
   if (wsShow['nofront']!=1)  {   // include in zindex manipulation list (move to front or back)
      let infronts=wsShowAll['zIndex'];
      if (infronts.hasOwnProperty(zid)) delete infronts[zid] ;    // already open, remove
      let zuse=1600 ;
      for (let zzid in infronts) {
        if (infronts[zzid][0]>zuse) zuse=parseInt(infronts[zzid][0]) ;     // find the largest zindex (in the init'ed elements)
      }
      let znow=zuse+1;
      let foo= [znow,e1,aidSay];
      infronts[zid]=foo ;    ; // this is in front "show" -- with e1
      wsShowAll['zIndex']=infronts;

      e1.css({'z-index':znow});       // move to front
   }

   wsShowAll['lastClick']=Date.now();
 //  wsurvey.dumpObj(wsShowAll,1,' xEnd wsshow all on show of: end '+aid);
   $(document).data('wsShowAll',wsShowAll);  // for later use!     lastShow

   return 1 ;

}     // end of .show

//====================================
// hide an elememt. If this has been wsInit'ed, then also remove from zindex and lastShow lists
// return 0 if error, 1 if hidden
// fadeMsec is optional. If specified, a postive numbret > 0 -- milliseconds used to fadeOUt the element

wsurvey.wsShow.hide=function(aid,fadeMsec) {
   if (arguments.length<2) fadeMsec=0;
   if (!jQuery.isNumeric(fadeMsec) || fadeMsec<0) fadeMsec=0;
   let e1=wsurvey.wsShow.argJquery(aid);
   if (e1===false) {
      if (typeof(aid)=='string') {    // try prepending a '#'
          aid='#'+aid;
          e1=wsurvey.wsShow.argJquery(aid);
      }
    }

   if (e1===false) {
      alert('Unable to find element: '+aid);
      return 0;
   }

   if (e1.length==0) return 0 ; // an error
   if (typeof(e1.data('wsShow'))=='undefined')   {  // this has not been initialized... perhaps its a button
      let abutton=e1.wsShowAttr('data-wsshow',false);
      if (abutton===false || jQuery.trim(abutton)=='')   {  // not a button, but not wsSHow init'ed --  just hide this and be done
         e1.hide();
         return 1;
      }

     let goid=wsurvey.wsShow.resolveTarget(e1,abutton);
      if (goid===false) return 0;
      let xx=wsurvey.wsShow.hide(goid);   // maybe the target is initialized?
      return xx;
   }

// if here, hide aid!
   e1.stop(true,true);  // stop any current animation
   if (fadeMsec>0) {
      e1.fadeOut(fadeMsec) ;
   } else {
      e1.hide()         ;
   }

// remove from zindex and lastShow lists
   let wsShowAll=$(document).data('wsShowAll');
   if (typeof(wsShowAll)=='undefined')  {  // shouldn't happen, but wth
      wsShowAll={'zIndex':{},'lastShow':{},'lastClick':0};
   }

//   if (typeof(wsShowAll)=='undefined') return 1 ;             // not in any list, so done

   let wsShow=e1.data('wsShow');    // must be initialized if one is here!
   let zid=wsShow['id'];   // internal id of this "shown" element

// don't bother checking noesc or nozindex (let hasOwnProperty do it implicitly)
   if (wsShowAll['zIndex'].hasOwnProperty(zid)) delete wsShowAll['zIndex'][zid];
   if (wsShowAll['lastShow'].hasOwnProperty(zid)) delete wsShowAll['lastShow'][zid];

   $(document).data('wsShowAll',wsShowAll);
   return 1 ;

}    // end of .hide


//==================
// return element given a value of data-wsshow  ... check for specifal values
// a button. Check for special values!
wsurvey.wsShow.resolveTarget=function(e1,abutton) {

    if (jQuery.isNumeric(abutton))  {   // look for nth ancestor
      if (abutton>=0) return false ;        // should be < 0
      let eancestor=e1.parent()
      for (let mm=0;mm>abutton;mm--) {           // go back abutton ancestors
         if (mm!=0) eancestor=eancestor.parent();  // go back again?
         let atag='';
         if (eancestor.length==1) atag=eancestor.prop('tagName').toLowerCase();
         if (eancestor.length!=1 || atag=='body' || atag=='html') return  false; // give up
      }
      return eancestor ;
    }

    if (abutton.substr(0,1)=='~') {   // look for "closest
       let bbutton=abutton.substr(1);
       let eancestor=e1.closest(bbutton);
       let atag='';
       if (eancestor.length==1) atag=eancestor.prop('tagName').toLowerCase();
       if (eancestor.length!=1 || atag=='body' || atag=='html') return false; // give up
       return eancestor
    }

// else, use abutton as is
    e2=wsurvey.wsShow.argJquery(abutton);
    if (e2.length!==1) return false;
    return e2;

}


//=================
// remove most recently shown
// typically called as an esc handler -- so check key to see if it is an escape
// if called with no arguments, remove most recently show (don't check if esc key was hit)
wsurvey.wsShow.hideRecent=function(aevent) {

  if (arguments.length>0)   {           // if no args, don't check for esc key
     let myKey=aevent.keyCode;
     if (myKey!=27) return 0  ;
  }

  let wsShowAll=$(document).data('wsShowAll');
  if (typeof(wsShowAll)=='undefined') return 0 ;             // not in any list, so done

  let lastShow=wsShowAll['lastShow'];
  let was1=-1000000000000,use1=false;
  for (zid0 in lastShow) {
     let atime=lastShow[zid0][0];
     if (atime>was1) {
         use1=zid0 ;
         was1=atime;
     }
  }
  if (use1===false) return 0 ;  // maybe list was empty?

  let euse=lastShow[use1][1];
  delete lastShow[use1] ;    // get rid of this entry
  wsShowAll['lastShow']=lastShow;

  if (!euse.is(':visible')) {      //perhaps hidden by something else... find the next one to hide
     $(document).data('wsShowAll',wsShowAll) ;
     xx=wsurvey.wsShow.hideRecent(aevent) ;
     return xx;
  }

  euse.stop(true,true);  // stop any current animation
  euse.hide();      // Hide it!

// might as well remove this from the zIndex list...
  let zIndex=wsShowAll['zIndex'];
  if (zIndex.hasOwnProperty(use1)) delete zIndex[use1];
  wsShowAll['zIndex']=zIndex;

  $(document).data('wsShowAll',wsShowAll) ;


  return 1;


}

//============
// move element to front or back -- of set of init'ed elements
// qDouble, if specified and = 1, means  "move to back"
// Otherwise, move to front on a click -- but on a second quickly recieved click  (a double click), move to back

wsurvey.wsShow.inFront=function(aid,toBack) {

   let e1=wsurvey.wsShow.argJquery(aid);
   if (e1===false) {
      if (typeof(aid)=='string') {    // try prepending a '#'
          aid='#'+aid;
          e1=wsurvey.wsShow.argJquery(aid);
       }
   }

   if (e1.length==0) return 0 ; // an error

   if (arguments.length<2) toBack=0;

   if (typeof(e1.data('wsShow'))=='undefined')   {  // this has not been initialized... perhaps its a button

      let abutton=e1.wsShowAttr('data-wsshow',false);
      if (abutton===false || jQuery.trim(abutton)=='')   return 0;   // not a button, but not wsSHow init'ed --  give up
      let goid=wsurvey.wsShow.resolveTarget(e1,abutton);
      let xx=wsurvey.wsShow.inFront(goid,toBack);       // try using the button's target
      return xx ;
   }

// set this z-index to be more than, or less than (if double click) all the other "inited' elements

  let wsShow=e1.data('wsShow');    // must be initialized if one is here!

   nowTime=Date.now();
   lastClick=wsShow['lastClick'];
   mSec=nowTime-lastClick ;
   wsShow['lastClick']=nowTime;
   e1.data('wsShow',wsShow);
   let doubleM=wsShow['double'];

   let qdouble=false;
   if (toBack==1) {
      qdouble=true;
   } else {
     qDouble= (mSec<doubleM) ? true : false ;  // double click?
   }

   let zid=wsShow['id'];   // internal id of this "shown" element

  let wsShowAll=$(document).data('wsShowAll');
  if (typeof(wsShowAll)=='undefined') return 0 ;             // not in any list, so done

  let zIndex=wsShowAll['zIndex'];
  was1= (qDouble) ? 10000000000 : -10000000000000 ;
  let use1=false;

  for (zid2 in zIndex) {
     let az=parseInt(zIndex[zid2][0]);
     if (qDouble) {      // double click -- to back
       if (az<was1) {
          was1=az;
          use1=zid2;
       }
     } else {            // not double click -- to front
       if (az>was1) {
          was1=az;
          use1=zid2;
       }
     }
  }
  if (use1==false) return 0 ;  // maybe an empty lsit?

  znow = (qDouble) ? was1-1 : was1+1 ;
  zIndex[zid]=[znow,e1];   // might overwrite prior entry

  wsShowAll['zIndex']=zIndex;
  $(document).data('wsShowAll',wsShowAll);

  e1.css({'z-index':znow});        // and finally, change the display!


  return 1 ;

}

//===========
// some utilities (local versions of wsurvey.utils1.js functions
wsurvey.wsShow.argJquery=function(ado,which) {
    if (ado instanceof jQuery)  return ado ;  // already jquery object
    if (arguments.length<2) which='target';

    if (which!='target' && which!=='currentTarget' && which!=='delegateTarget' && which!=='relatedTarget') which='target';

    if (typeof(ado)=='string') {       // a bit of overkill to use this, but will deal with prepended #
       let ado2=jQuery.trim(ado);
       ado2= (ado.substr(0,1)!='#') ? '#'+ado2 : ado2 ;
       oof=jQuery(ado2);
       if (oof.length==0) return false ;
       return oof ;
    }
     if (typeof(ado)!=='object') return false ;   // should rarely happen

     if (typeof(ado.originalEvent)!=='undefined' && typeof(ado.target)!=='undefined') {  // .on ()
         let e1=jQuery(ado[which]);  // from an .on
         e1['argJqueryData']={} ;
         if (typeof(ado['data'])!='undefined') e1['argJqueryData']=ado['data'];
         return e1;
     }

     if (typeof(ado.currentTarget)!=='undefined' && typeof(ado.target)!=='undefined') {    // addeventlistener
         let e1=jQuery(ado[which]);  // from an .on
         e1['argJqueryData']={} ;
         if (typeof(ado['data'])!='undefined') e1['argJqueryData']=ado['data'];
         return e1;
     }

     oof=jQuery(ado);                  // a inline call  using (this) (no .data)
     if (oof.length==0) return false;  // but maybe its not an inline call
     return oof;

}

jQuery.fn.wsShowAttr = function (lookForAttr,adef ) {

     var elem = this;         // this is alreach a jQuery object
     if(!(elem && elem.length)) return false ;  // not a legit jquery object (minimal test)

     var allAttsOrig=elem.get(0).attributes ;
     lookForLc=jQuery.trim(lookForAttr).toLowerCase();

     for (var mm=0;mm<allAttsOrig.length;mm++) {
           let n0=allAttsOrig[mm]
           let n = n0.nodeName||n0.name;
           let nLc=jQuery.trim(n.toLowerCase());
           if (nLc==lookForLc) {
              let v = elem.attr(n);
              return v;
           }
     }
     return adef;

}  // wsattr

