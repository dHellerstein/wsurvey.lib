<?php

// This is for developer use. It requires the "mathias" minify package
// This will minify all the .js files in js/, and write .min.js versions to js/mins/
// It uses the "mathias" minify package   https://github.com/matthiasmullie/minify/

// Note use of the path to the mathias minify package. I

$path = 'D:/wamp/www/tools/minifyRoot';
require_once $path . '/minify/src/Minify.php';
require_once $path . '/minify/src/CSS.php';
require_once $path . '/minify/src/JS.php';
require_once $path . '/minify/src/Exception.php';
require_once $path . '/minify/src/Exceptions/BasicException.php';
require_once $path . '/minify/src/Exceptions/FileImportException.php';
require_once $path . '/minify/src/Exceptions/IOException.php';
require_once $path . '/path-converter/src/ConverterInterface.php';
require_once $path . '/path-converter/src/Converter.php';

/*
use MatthiasMullie\Minify;

    $sourcePath = '/path/to/source/css/file.css';
    $minifier = new Minify\CSS($sourcePath);

    // we can even add another file, they'll then be
    // joined in 1 output file
    $sourcePath2 = '/path/to/second/source/css/file.css';
    $minifier->add($sourcePath2);

    // or we can just add plain CSS
    $css = 'body { color: #000000; }';
    $minifier->add($css);

    // save minified file to disk
    $minifiedPath = '/path/to/minified/css/file.css';
    $minifier->minify($minifiedPath);

    // or just output the content
    echo $minifier->minify();
*/
use MatthiasMullie\Minify;

 $jsPath='D:/wamp/www/wsurvey.distrib/wsurvey.lib/js/*.js';
 $dirs0=glob($jsPath);

 print "Minify wsurvey.lib/js/*.js .... <br> ";
 
 foreach ($dirs0 as $ii=>$afile) {
//  $sourcePath = 'D:/wamp/www/wsurvey.lib/js/wsurvey.floatingContent.js';

  $fileName=pathInfo($afile,PATHINFO_BASENAME);
  $justFileName= pathInfo($afile,PATHINFO_FILENAME);
  $jsMinFile='D:/wamp/www/wsurvey.distrib/wsurvey.lib/js/mins/'.$justFileName.'.min.js';

  $minifier = new Minify\JS($afile);
  $aheader="// Minify $justFileName on ". date('d-M-Y h:i')."\n";
  $gar=$minifier->minify();
  $stuff=$aheader.$gar;
  print "<br>$justFileName : $afile to  $jsMinFile : ";
  $nn=file_put_contents($jsMinFile,$stuff) ;
  print " $nn bytes \n";

  continue;
 }

print "\n<br> done! ";