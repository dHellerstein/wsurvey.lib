Feb 2022

This directory contains miscellaneous javascript, and php, libraries that are  pulled from the public domain.
They are, or may be, used by the wsurvey. family of programs and libraries

Please see the files for attribution informaton 