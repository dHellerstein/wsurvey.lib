<?php
//Example of a logon paramers: used by  wsurvey.adminLogon.php

// the defaults
$passwordActual="a";                   // Required. The "admin" password (it will be hashed when sent to server). It MUST be specified
$pwdDuration=2000;                     // Default =2000. in milliseconds (pwd expires after this amount of time

// for user specific values, add to wsurveyadminLogon_params['logonName']. For example:
//  For example= $wsurveyadminLogon_params['dogMan']=['passwordActual'=>'fido35',$pwdDuration'=>1500,'callbackLogon'=>'dogCallback'];
//$wsurveyadminLogon_params['gallery']=['passwordActual'=>'a','pwdDuration'=>2000,'callbackLogon'=>'wsGallery_logonCallback'];
//$wsurveyadminLogon_params['wsGallery']=['passwordActual'=>'aa','pwdDuration'=>2000,'callbackLogon'=>'wsGallery_logonCallback'];

?>
